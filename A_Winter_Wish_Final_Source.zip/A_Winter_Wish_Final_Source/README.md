# 雪夜来信 · A Winter Wish

这是《雪夜来信》的维护源码。两个成品 HTML 与源码压缩包一并交付。解压后的 `offline/` 已包含演示数据，运行打包命令即可在该目录生成两个 HTML。每个 HTML 都可以独立离线打开。

## 打开与分享

- 用浏览器打开创作版 `A_Winter_Wish_Letter_Song_Lite.html`，进入 ATELIER，最多可添加 24 张照片并写信。
- 支持本地存储时，草稿自动保存在当前浏览器。用同一个浏览器重新打开原路径的创作版即可继续。想换浏览器或设备时，先「下载草稿」，再到创作版里「打开草稿」。可用「清除草稿」删除此文件的本地草稿并重置编辑器。
- 写好后点击「导出分享 HTML」，将生成的 `A_Winter_Wish_Gift.html` 发给收件人。照片、信件、雪景和音频全部内嵌，只需发送这一个文件。聊天附件预览可能显示源码，收件人可下载后用浏览器打开。
- 演示版 `A_Winter_Wish_Letter_Song_Lite_Demo.html` 内置 20 张示例照片和一封信，可直接体验收件人看到的效果。
- 用鼠标时，上下工具栏在拆信后隐藏。鼠标移到画面顶边或底边，两栏一起出现，移开后一起淡出。也可用 Tab 找到工具栏按钮。触屏可以直接操作上下栏。
- 手机上可横向拖动转树，序幕中横向拖动也可直接进入雪景。手机开启「减少动态效果」时，树周围的灯光仍会缓缓流动，散开的照片会变速环绕、轮流靠近镜头。雪橇在手机上采用较从容的进场节奏。
- 拖动旋转，滚轮缩放，点树散开回忆。可以点浮动照片，也可以点「收拢照片」。右上角木牌和底部「雪橇来信」都可以触发雪橇。雪铺满后可擦去雪花或点「直接读信」。在纸面上可点「读完整来信」或「返回圣诞树」。浏览器无法显示 WebGL 雪景时，可以继续读信。
- 打开后先看到一封带音乐火漆印章的信。点击信封，或在键盘上按 Enter，信封散开，同时开始播放音乐。右上角 ♪ 可以静音或恢复播放。雪橇甩尾时第一首淡出，转弯摆完第二首从头播。回到树后第二首继续播放，播完停约 0.7 秒再回第一首。

## 构建与回归

```bash
node scripts/pack.mjs              # 两个离线 HTML；--creator-only 仅构建创作版
node scripts/verify.mjs            # 构建 + 核心回归；仅需 Node.js 22+
```

可在本目录安装 `@napi-rs/canvas`，再运行 `node scripts/verify.mjs --with-geometry`，验证桌面/竖屏、照片导入、光照、轨迹、雪层和交互。此测试使用实际 Three.js 场景与模拟渲染边界，不代替 Chrome/Edge 真机画面与声音验收。可选的 `node tests/browser.mjs` 需要已安装 Playwright 与 Chromium；支持真正的离线浏览器检查。打包与打开成品都无需安装测试依赖。

离线打包使用已压缩的 `dist/three.offline.js`，模块开发使用可读的 `dist/three.module.js`。更新 Three.js 时，安装 `esbuild@0.25.12`，运行 `node scripts/pack.mjs --refresh-three` 重新生成压缩副本。Three.js 的 MIT 许可保留在 `dist/three-LICENSE.txt` 和运行时代码中。

## 从哪里改代码

| 内容 | 源码 |
|---|---|
| 页面、UI、输入、相机和接线 | `dist/index.html`、`dist/style.css`、`dist/app.js` |
| 故事状态、木牌与旋转时钟 | `dist/state.js`、`dist/bell.js` |
| 天光、雪景、树和照片 | `dist/environment.js`、`dist/world-build.js`、`dist/fir.js`、`dist/photos.js` |
| 雪橇、驯鹿、擦雪和信纸 | `dist/sleigh-sequence.js`、`dist/reindeer.js` |
| 音轨、淡入淡出、空间声 | `dist/audio.js`；内嵌资产与署名在 `dist/audio-recordings.js` |
| 个人照片、信件和导出 | `dist/personalize.js`、`scripts/pack.mjs` |
| 演示内容 | `offline/demo-data-flurry.json`；通常不需要重新生成 |

不要直接维护生成后的 HTML。音频来源可在页面的 ⓘ 查看。场景几何、Shader、音频轨迹及关键定时以确认成品为基准；`tests/accepted-parity.mjs` 对这些模块做指纹比对。
