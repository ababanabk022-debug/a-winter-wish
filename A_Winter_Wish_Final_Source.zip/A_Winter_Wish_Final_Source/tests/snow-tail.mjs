import assert from 'node:assert/strict';
import * as T from '../dist/three.module.js';
import {createSleighSequence} from '../dist/sleigh-sequence.js';
import {createReindeer} from '../dist/reindeer.js';
import {groundHeight} from '../dist/environment.js';
import {makeState,portraitFlightFrame} from '../dist/state.js';

for (const [aspect,lowQuality,reduced,touchScene=false] of [
  [16/9,false,false],[390/844,true,false],[2.39,false,false],[16/9,true,true],
  [390/844,true,false,true],[390/844,true,true,true],
]) {
  const scene=new T.Scene(),camera=new T.PerspectiveCamera(aspect<1?49:40,aspect,.05,380);
  camera.position.set(0,1.86,11.7);
  camera.lookAt(aspect<1?0:-.39,2.48,0);
  camera.updateMatrixWorld(true);
  const state=makeState(reduced,{touchScene});
  const seq=createSleighSequence(T,scene,camera,{groundHeight,lowQuality,flightSeconds:state.flightSeconds,makeReindeer:createReindeer});
  const timing=seq.flightTiming(),{onsetPlayback,impactPlayback,fullPlayback,endPlayback,secondsPerProgress}=timing;
  assert(Math.abs((impactPlayback-onsetPlayback)*secondsPerProgress-1.8)<1e-9);
  assert(Math.abs((fullPlayback-impactPlayback)*secondsPerProgress-.75)<1e-9);
  assert(endPlayback>fullPlayback&&seq.flightEnd()===endPlayback);
  const wake=seq.group.children.find(o=>o.name==='Drift · continuous runner plume');
  assert(wake?.isMesh&&wake.material.depthTest&&!wake.material.depthWrite,'plume must live in 3D behind world geometry');
  const localLights=[];seq.group.traverse(o=>{if(o.isLight)localLights.push(o);});
  assert(localLights.length>0&&localLights.every(l=>l.isPointLight&&l.distance>0),'no scene-wide hemispheric flash when the sleigh group appears');
  const paperSurface=seq.group.children.flatMap(o=>o.children).flatMap(o=>o.children).find(o=>o.renderOrder===997);
  assert(paperSurface?.isMesh);
  const step=raw=>{
    const geometry=seq.motionProgress(raw);
    const follow=portraitFlightFrame(Math.max(0,geometry),aspect);
    camera.position.z=11.7+follow.pullBack;
    camera.lookAt(aspect<1?follow.aimX:-.39,2.48,0);camera.updateMatrixWorld(true);
    seq.update(raw,0,0,raw*secondsPerProgress);scene.updateMatrixWorld(true);return seq.snowDiagnostics();
  };
  const fromOnset=seconds=>onsetPlayback+seconds/secondsPerProgress;
  const fromHit=seconds=>impactPlayback+seconds/secondsPerProgress;
  step(-.17);assert(localLights.every(l=>l.intensity===0),'local light starts faded out');
  for(let frame=0;frame<80;frame++){
    const raw=-.17+(onsetPlayback+.17)*(frame/80),info=step(raw);
    assert(!wake.visible&&seq.plumeDiagnostics().rows===0&&info.visible===0&&info.cover===0,'no wake before the pictured pose');
  }
  step(onsetPlayback);
  const root=seq.rig.getWorldPosition(new T.Vector3()),nose=new T.Vector3(1,0,0).applyQuaternion(seq.rig.getWorldQuaternion(new T.Quaternion()));
  assert(root.x>2.7&&root.z>1.1&&nose.x<-.89,'first throw begins right of fir, sleigh distinctly facing screen left');
  assert(root.clone().project(camera).x>.27,'actual camera reads reference side');
  const start=step(fromOnset(.07)),early=seq.plumeDiagnostics(),shoe=new T.Vector3(...early.leadOrigin);
  assert(start.cover===0&&wake.visible&&early.rows>=3&&early.pressure>.10);
  assert(Math.abs(shoe.y-groundHeight(shoe.x,shoe.z))<.024,'leading powder comes directly from snowy rear shoe');
  assert(shoe.clone().sub(root).dot(nose)<-.17,'launch is aft of the sleigh');
  let travel=early.leadTravel,width=early.width,height=early.height;
  for(const secs of [.24,.48,.75,1.03,1.30,1.53,1.73]) {
    const sample=step(fromOnset(secs)),p=seq.plumeDiagnostics();
    assert(sample.cover===0&&sample.landed===0,'no film can appear before 1.8s strike');
    assert(p.rows>=3&&p.leadTravel>travel&&p.width>width&&p.height>height,'same lead cohort travels toward lower screen; cloud expands with approach');
    travel=p.leadTravel;width=p.width;height=p.height;
  }
  const first=step(impactPlayback);
  assert(first.landed>=1&&first.hitPlayback===impactPlayback&&first.hitUv[0]>.7&&first.hitUv[1]<.12);
  const avg=(v)=>[.1,.3,.5,.7,.9].reduce((sum,u)=>sum+seq.snowDensityAt(u,v)/5,0);
  const dense=(dt,v)=>{step(fromHit(dt));return avg(v);};
  assert(dense(.150,.04)>.62&&avg(.52)===0&&avg(.87)===0);
  assert(dense(.2625,.20)>.75&&avg(.52)<.03);
  assert(dense(.4125,.52)>.60&&avg(.87)<.055);
  assert(dense(.58125,.87)>.38&&avg(.96)<.46);
  assert(dense(.755,.96)>.95);
  for(let dt=.015;dt<.75;dt+=1/120){step(fromHit(dt));assert(!paperSurface.parent.visible&&paperSurface.material.opacity===0,'no letter flash before full cover');}
  step(endPlayback);assert(paperSurface.parent.visible&&paperSurface.material.opacity===1,'paper is ready by the interaction handoff');
  assert(localLights.every(l=>l.intensity===0),'local key is already faded out by handoff');
  step(fromHit(.20));
  const top=x=>Array.from({length:101},(_,j)=>j/100).filter(v=>seq.snowDensityAt(x,v)>.5).at(-1);
  assert(top(.86)>top(.14),'lower-right lean retained');
  state.ready();state.flight(seq.flightEnd());
  let fullWhileFlying=false;
  for(let i=0;i<650&&state.phase==='flight';i++){
    state.tick(1/60);const f=step(state.sleigh);
    if(f.cover===1&&state.phase==='flight')fullWhileFlying=true;
    if(state.phase==='snow')assert(fullWhileFlying&&f.cover===1,'full coverage precedes state handoff');
  }
  assert.equal(state.phase,'snow');
  const covered=seq.trace(.65,.52,.49,.51);
  assert(covered>0&&covered<.4&&seq.sampleMask(.57,.515)>.99&&seq.sampleMask(.86,.73)===0);
  seq.resetTrace();assert.equal(seq.sampleMask(.57,.515),0);assert.equal(step(-.17).cover,0);
  seq.dispose();assert.equal(scene.children.length,0);
  console.log(aspect.toFixed(3),touchScene?'touch':'default',reduced?'reduced':'standard',{onset:(onsetPlayback+.17)*secondsPerProgress,contact:(impactPlayback+.17)*secondsPerProgress,full:(fullPlayback+.17)*secondsPerProgress});
}
