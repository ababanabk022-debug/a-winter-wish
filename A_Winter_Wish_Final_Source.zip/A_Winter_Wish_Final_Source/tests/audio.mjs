import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {makeWishAudio,wishSleighDynamics} from '../dist/audio.js';
import {wishAudioMedia} from '../dist/audio-recordings.js';

const score=Buffer.from(wishAudioMedia.music,"base64");assert.equal(createHash("sha256").update(score).digest("hex"),"4e999469f3e5146ace9fe8c88c6e3266ff5c2dd31eca22d8a0e14893eb1798ea");
assert.equal(wishAudioMedia.credits.at(-1).author,'az_studio');
assert.equal(wishAudioMedia.credits.at(-1).license,'Pixabay Content License');
assert.match(wishAudioMedia.credits.at(-1).changes,/Content ID registered/);
assert.deepEqual(wishAudioMedia.credits.slice(0,3).map(c=>[c.author,c.license]),[['The Midnite Wolf','CC0 1.0'],['Nox_Sound','CC0 1.0'],['Percy Duke','CC BY 3.0']]);
for(const [key,sha] of Object.entries({
 bells:'6ecb7690f6e221aa21f575dd1768b72797f313e97d3820024112867dfe6c1107',
 slide:'8bbcc417ff648af8390f039e50ec3cbf38a654901ddd5fbbb3b26d8aceb2d099',
 drift:'d027eeb318e11a2c00ba9adcf0100a609e60e9fd476d077007a3d9f44de24e5e'
}))assert.equal(createHash('sha256').update(Buffer.from(wishAudioMedia[key],'base64')).digest('hex'),sha,key+' foley must remain byte-identical');
const snowPayloads=['slide','drift'].map(k=>Buffer.from(wishAudioMedia[k],'base64'));
assert(snowPayloads.every(x=>x.length>24000&&x.length<52000));
const payload=Buffer.from(wishAudioMedia.bells,'base64');assert(payload.length>55000&&payload.length<65000);
class Param{value=0;events=[];cancelAndHoldAtTime(){}setTargetAtTime(v,t,d){this.events.push({v,t,d});}setValueAtTime(v){this.value=v;}}
class FakeContext{
 state='suspended';currentTime=0;nodes=[];sources=[];decodes=[];destination={};
 node(kind){const v={kind,connect(){},disconnect(){}};this.nodes.push(v);return v;}
 createGain(){return Object.assign(this.node('gain'),{gain:new Param()});}
 createBuffer(){throw Error('synthesized audio must not be used');}
 createWaveShaper(){return this.node('peak-guard');}
 createBiquadFilter(){return Object.assign(this.node('eq'),{frequency:new Param(),gain:new Param()});}
 createStereoPanner(){return Object.assign(this.node('pan'),{pan:new Param()});}
 decodeAudioData(ab,ok){this.decodes.push(Buffer.from(ab));const b={duration:9.85};ok(b);return Promise.resolve(b);}
 createBufferSource(){
  const o=Object.assign(this.node('bufferSource'),{starts:[],stops:[],start(t,offset=0){this.starts.push({t,offset});},stop(t){this.stops.push(t);}});this.sources.push(o);return o;
 }
 resume(){this.state='running';return Promise.resolve();}
 suspend(){this.state='suspended';return Promise.resolve();}
 close(){this.state='closed';return Promise.resolve();}
}
const ctx=new FakeContext();let init=0;
const audio=makeWishAudio({ctxFactory:()=>{init++;return ctx;}});
audio.update({phase:'intro'});assert.equal(init,0);
audio.setMuted(true);assert.equal(await audio.unlock(),false);assert.equal(init,0);
audio.setMuted(false);assert.equal(await audio.unlock(),true);assert.equal(init,1);assert.deepEqual(ctx.decodes,[score,payload,...snowPayloads,Buffer.from(wishAudioMedia.letterMusic,'base64')]);
const guard=ctx.nodes.find(n=>n.kind==='peak-guard');
assert.equal(guard.oversample,'2x');
assert.equal(guard.curve[1536],.5,'typical music amplitude is unaltered');
assert(guard.curve[2048]<.94,'guard only catches peak pileups');
for(const phase of ['intro','tree','snow','letter'])audio.update({phase,flightProgress:.7});
assert.equal(ctx.sources.length,1,'only music begins outside flight');
assert.equal(ctx.sources.shift().loop,true,'recorded music loops after unlock');
const fly=(p,time)=>{ctx.currentTime=time;audio.update({phase:'flight',flightProgress:p,pan:p*2-1,depth:15-p*9});};
fly(-.169,0);
assert.equal(ctx.sources[0].starts[0].offset,2.27,'travel bells cue starts from the strong recorded double-jingle while sleigh is off-axis left');
assert(ctx.sources[0].loopEnd<7.1,'trim the quiet tail of the ring asset during slow flight');
assert.equal(ctx.sources[1].starts[0].offset,.64,'use the salient pickup of the independent continuous snow glide');
const far=wishSleighDynamics(-.13,-1,17);
assert(far.bell>.70&&far.pan<-.9&&far.glide>.19&&far.drift===0,'left edge hears stronger harness jingle distinct from snow');
for(let i=0;i<60;i++)fly(i/100,.06+i*.045);
assert.equal(ctx.sources.length,2,'arrival bells and runner glide, no scrape before visible runner throw');
assert(ctx.sources.every(x=>x.loop));
fly(.604,2.75);assert.equal(ctx.sources.length,2);
fly(.605,2.76);assert.equal(ctx.sources.length,3,'separate scrape begins exactly when runner throws snow');
assert.equal(ctx.sources[2].loop,false,'the drift scrape is a one-shot, never repeated in a flight');
for(let i=61;i<100;i++)fly(i/100,2.77+(i-61)*.045);
assert.equal(ctx.sources.length,4,'two arrival sources, one drift and one transition-only score');
const eq=ctx.nodes.find(o=>o.kind==='eq');
assert.equal(eq.type,'highshelf');assert.equal(eq.frequency.value,1550);
assert(eq.gain.events.some(x=>x.v>7.4)&&eq.gain.events.some(x=>x.v<.004),'arrival presence backs off before foreground');
const pan=ctx.nodes.find(o=>o.kind==='pan').pan.events;
assert(pan.some(x=>x.v<-.65)&&pan.some(x=>x.v>.64));
assert(ctx.sources.slice(0,3).every(x=>x.stops.length===1),'every sleigh sound fades/stops on exit');
const musicGain=ctx.nodes.filter(o=>o.kind==='gain')[1].gain;
assert(musicGain.events.some(({v})=>v<.365)&&musicGain.events.some(({v})=>v===0),'background score ducks only ~2 dB');
assert(Math.abs(musicGain.events.at(-1).v)<.004,'first score fades out across drift');
const exit=ctx.currentTime;
fly(.5,exit+.03);assert.equal(ctx.sources.length,4,'no quick replay overlap while previous pass fades');
fly(.5,exit+.16);assert.equal(ctx.sources.length,6);
audio.setMuted(true);assert(ctx.sources.slice(4).every(x=>x.stops.length===1));
await new Promise(r=>setTimeout(r,152));assert.equal(ctx.state,'suspended');
audio.setHidden(true);audio.setHidden(false);assert.equal(ctx.state,'suspended');
audio.setMuted(false);assert.equal(ctx.state,'running');
assert.equal(audio.jingleTree,undefined,'rejected ornament synth is not in the public audio API');
audio.update({phase:'tree'});ctx.currentTime+=.3;assert.equal(ctx.sources.length,6,'tree adds no sound source');
audio.dispose();assert.equal(ctx.state,'closed');
console.log('PASS exact offline bells/glide/drift MP3 playback, opt-in, spatial pan, no non-flight playback, exit and replay release, muted/hidden gating');
