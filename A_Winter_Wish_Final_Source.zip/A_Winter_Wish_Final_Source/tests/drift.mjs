import {createReindeer} from '../dist/reindeer.js';
import * as T from '../dist/three.module.js';import {createSleighSequence} from '../dist/sleigh-sequence.js';import {makeEnvironment} from '../dist/environment.js';
import {portraitFlightFrame,makeState} from '../dist/state.js';
import {createRequire} from 'node:module';import assert from 'node:assert/strict';import fs from 'node:fs';
const {createCanvas,Path2D}=createRequire(import.meta.url)('@napi-rs/canvas');globalThis.document={createElement:()=>createCanvas(1,1)};globalThis.Path2D=Path2D;
const expected=JSON.parse(fs.readFileSync(new URL('./approved-drift-track.json',import.meta.url),'utf8'));
const scene=new T.Scene(),env=makeEnvironment(T,scene);
const state=makeState();assert.equal(state.phase,'intro');state.flight();assert.equal(state.phase,'intro','no flight allowed during formation');state.ready();state.flight();assert.equal(state.sleigh,-.17);
state.tick(.816);assert(Math.abs(state.sleigh)<1e-12);state.tick(4.8);assert.equal(state.phase,'snow');state.replay();assert.equal(state.phase,'intro');
for(const a of [1.714,.462,2.39]){
 const c=new T.PerspectiveCamera(a<1?Math.max(41,2*Math.atan(2.5/(11.7*a))*180/Math.PI):40,a,.05,380);scene.add(c);c.position.set(0,1.86,11.7);c.lookAt(a<1?0:-.39,2.48,0);c.updateMatrixWorld();
 const seq=createSleighSequence(T,scene,c,{lowQuality:true,groundHeight:env.groundHeight,makeReindeer:createReindeer});
 const pose=()=>{scene.updateMatrixWorld(true);const p=seq.rig.getWorldPosition(new T.Vector3()),q=seq.rig.getWorldQuaternion(new T.Quaternion()),s=seq.rig.getWorldScale(new T.Vector3());return {p,q,s,forward:new T.Vector3(1,0,0).applyQuaternion(q).setY(0).normalize()}};
 function tick(f,raw=false){const actual=raw&&seq.motionProgress?seq.motionProgress(f):f;const follow=portraitFlightFrame(Math.max(0,actual),a);c.position.z=11.7+follow.pullBack;c.lookAt(a<1?follow.aimX:-.39,2.48,0);c.updateMatrixWorld(true);seq.update(raw?f:seq.playbackProgress?.(f)??f,0,0,2+f*4.8);return pose();}
 {
  seq.setIntro(0,2);seq.group.visible=false;const visible=()=>{let o=seq.rig;while(o){if(!o.visible)return false;o=o.parent}return true};assert.equal(visible(),false,'Santa cannot be rendered in idle/intro');
  const launch=tick(-.17).p.clone(),frame=launch.clone().project(c);assert(frame.x< -1.1&&launch.x<0,'left launch offscreen');
  seq.rig.updateWorldMatrix(true,true);const right=new T.Box3().setFromObject(seq.rig);let xMax=-Infinity;
  for(const x of [right.min.x,right.max.x])for(const y of [right.min.y,right.max.y])for(const z of [right.min.z,right.max.z])xMax=Math.max(xMax,new T.Vector3(x,y,z).project(c).x);
  assert(xMax< -1.005,'entire starter sled must begin outside left edge '+xMax);
  const run=[];const end=seq.playbackProgress(.69);
  for(let i=0;i<=254;i++)run.push(tick(-.17+(end+.17)*i/254,true).p);
  const increments=run.slice(1).map((p,i)=>Math.hypot(p.x-run[i].x,p.z-run[i].z));const top=Math.max(...increments),floor=Math.min(...increments);
  assert(floor>.03&&top/floor<1.006,'constant approach cannot brake at the old splice or on turn: '+floor+'/'+top);
  const join=seq.playbackProgress(.13),velBefore=tick(join,true).p.sub(tick(join-.0005,true).p).multiplyScalar(2e3),velAfter=tick(join+.0005,true).p.sub(tick(join,true).p).multiplyScalar(2e3);
  assert(velBefore.setY(0).distanceTo(velAfter.setY(0))<.20,'old splice cannot cause a velocity cusp');
  console.log('constant sweep distance '+a+' Δ='+floor.toFixed(5)+'–'+top.toFixed(5));
 }
 const frameList=[];let behind=0,backNear=0,arcMaxNDC=0,maxInset=0,minEnvelope=Infinity;
 for(let i=0;i<=174;i++){
  const f=.13+i*.005,here=tick(f);const flattened=[...here.p,...here.q,...here.s];
  {
   const old=expected[a][i],previousRadius=Math.hypot(old[0],old[2]),radius=Math.hypot(here.p.x,here.p.z);
   if(f<.314||f>.764)assert(flattened.every((n,j)=>Math.abs(n-old[j]*(j>=7?.37:1))<3e-6), 'pose outside contracted arc changed @'+f);
   else {
    const inset=previousRadius-radius;
    assert(inset>=-1e-6&&inset<=.671&&radius>3.7,'only the right turn contracts toward tree');
    maxInset=Math.max(maxInset,inset);
    if(i%2===0)seq.rig.traverse(mesh=>{
     if(!mesh.isMesh||mesh.isInstancedMesh)return;
     const attr=mesh.geometry?.getAttribute('position');if(!attr)return;
     const v=new T.Vector3();
     for(let k=0;k<attr.count;k+=8){v.fromBufferAttribute(attr,k).applyMatrix4(mesh.matrixWorld);
      const radiusFir=.23+1.9*Math.pow(Math.max(.01,(5.44-v.y)/4.98),.83);
      minEnvelope=Math.min(minEnvelope,Math.hypot(v.x,v.z)-radiusFir);
     }
    });
   }
  }
  frameList.push(flattened);
  if(f>.34&&f<.77)arcMaxNDC=Math.max(arcMaxNDC,Math.abs(here.p.clone().project(c).x));
  if(here.p.z < -1.7 && Math.abs(here.p.x)<1.2)behind++;
  const toTree=here.p.clone().multiplyScalar(-1).setY(0).normalize(),toLens=c.position.clone().sub(here.p).setY(0).normalize();
  if(here.p.z>2 && here.forward.dot(toTree)>.96&&here.forward.dot(toLens)<-.72)backNear++;
 }
 assert(maxInset>.65&&minEnvelope>.31,'tightened arc stays clear of the lowest fir branches and trims at least .65m');
 assert(behind>=6&&backNear>=9&&arcMaxNDC<1.05);seq.setIntro(0,10);seq.group.visible=false;seq.dispose();scene.remove(c);
 console.log(a,{approvedPoses:frameList.length,behind,backNear,arcMaxNDC,maxInset,minEnvelope});
}
