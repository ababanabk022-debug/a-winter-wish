import fs from 'node:fs';import assert from 'node:assert/strict';import {createRequire} from 'node:module';import {createHash} from 'node:crypto';
const {loadImage}=createRequire(import.meta.url)('@napi-rs/canvas');
const read=f=>fs.readFileSync(new URL('../offline/'+f,import.meta.url),'utf8');
const data=JSON.parse(read('demo-data-flurry.json'));
const payload=JSON.parse(read(process.argv[2]||'A_Winter_Wish_Letter_Song_Lite_Demo.html').match(/<script type="application\/json" id="wish-data">([\s\S]*?)<\/script>/)[1]);
assert.equal(payload.photos.length,20);assert.deepEqual(data,payload);assert.equal(payload.mode,'share');
const ph=payload.photos;
assert.equal(new Set(ph.map(p=>p.name)).size,20);
assert.equal(new Set(ph.map(p=>createHash('sha256').update(Buffer.from(p.src.split(',')[1],'base64')).digest('hex'))).size,20);
for(const p of ph){const image=await loadImage(p.src);assert.equal(image.width,480);assert.equal(image.height,336);}
console.log('PASS exact shipped demo includes 20 distinct decodable original procedural JPEGs, independently named.');
