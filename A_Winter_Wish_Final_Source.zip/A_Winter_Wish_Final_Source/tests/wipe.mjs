import * as T from '../dist/three.module.js';
import {createSleighSequence} from '../dist/sleigh-sequence.js';
import {createRequire} from 'node:module';import assert from 'node:assert/strict';
const {createCanvas,Path2D}=createRequire(import.meta.url)('@napi-rs/canvas');
globalThis.document={createElement:()=>createCanvas(1,1)};globalThis.Path2D=Path2D;
const scene=new T.Scene(),camera=new T.PerspectiveCamera(40,1.77,.05,380);scene.add(camera);
const seq=createSleighSequence(T,scene,camera,{lowQuality:true});seq.update(1,0,0,2);
for(const aspect of [.43,1.77,2.39,3.0]){
 camera.aspect=aspect;camera.updateProjectionMatrix();seq.update(seq.flightEnd(),0,1,8);
 const ray=new T.Raycaster(),hits=(x,y)=>{ray.setFromCamera(new T.Vector2(x,y),camera);return seq.letterContains(ray.ray)};
 assert(hits(0,0),'middle of actual tilted plane');
 assert(!hits(-.96,0)&&!hits(.96,0),'a real touch gutter exists even on portrait');
 assert(!hits(.95,.93),'far corner is not part of the actual tilted plane');
 seq.resetTrace();assert.equal(seq.sampleMask(.5,.5),0);
 const a=seq.trace(.60,.52,.4,.48);assert(a>0&&a<.6);
 assert(seq.sampleMask(.46,.491)>.75);assert.equal(seq.sampleMask(.01,.97),0);
 let cleared=a;
 // Deliberately erase only across the paper's physical center band, not the whole screen.
 const dx=Math.min(.31,.45/aspect);
 for(let y=.12;y<.89;y+=.051)cleared=seq.trace(.5+dx,y,.5-dx,y);
 assert(cleared>.64);
 assert.equal(seq.sampleMask(.01,.97),0);seq.resetTrace();assert.equal(seq.sampleMask(.46,.49),0);
}
seq.dispose();console.log('PASS actual lens brush erases only painted paths, tracks letter area to completion, leaves unpainted rim and resets at desktop ultrawide/mobile aspect ratios');
