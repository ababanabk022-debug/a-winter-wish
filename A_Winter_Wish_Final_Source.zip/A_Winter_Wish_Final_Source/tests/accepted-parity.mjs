import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
const tag=(html,id)=>html.match(new RegExp('<script[^>]*id="'+id+'"[^>]*>([\\s\\S]*?)</script>'))?.[1];
const blocks=r=>r.split(/^const \$m\d+=\(\(\)=>\{/m);
const normalized=(block,i)=>i===7?block.replace(/\/\/ Alternate time-based entry point[^]*?(?=return \{createReindeer,makeReindeer\};)/,'\n').replace('createReindeer,makeReindeer','createReindeer'):block;
const hash=s=>createHash('sha256').update(s).digest('hex');
const root=new URL('../',import.meta.url);
const read=(dir,name)=>fs.readFileSync(new URL(dir+'/'+name,root),'utf8');
const fingerprints=['','_Demo'].map(suffix=>{
 const name='A_Winter_Wish_Letter_Song_Lite'+suffix+'.html';
 const file=read('offline',name);
 return [tag(file,'wish-shell'),tag(file,'wish-data'),...blocks(tag(file,'wish-runtime')).slice(0,12).map(normalized)].map(hash);
});
const approval=new URL('approved-release-fingerprints.json',import.meta.url);
const original=JSON.parse(fs.readFileSync(approval,'utf8'));
// Demo artwork, mobile timing, and sky rendering have their own regression tests.
// Keep the creator payload and untouched modules pinned to the original release.
const unchanged=new Map([[5,'fir'],[8,'world build'],[9,'reindeer'],[12,'audio assets'],[13,'audio logic']]);
assert.equal(fingerprints[0][1],original[0][1],'creator payload changed');
for(const [variant,release] of fingerprints.entries()){
 for(const [index,name] of unchanged)assert.equal(release[index],original[variant][index],name+' changed in variant '+variant);
}
console.log('PASS original creator payload, preserved scene modules, audio logic and audio bytes.');
