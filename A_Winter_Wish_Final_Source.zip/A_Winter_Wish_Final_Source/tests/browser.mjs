// Run this with a WebGL-capable browser on an attached/compatible machine:
// npm i --no-save playwright && npx playwright install chromium && node tests/browser.mjs
import {createRequire} from 'node:module';import {pathToFileURL,fileURLToPath} from 'node:url';import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
const {chromium}=createRequire(import.meta.url)('playwright');
const root=fileURLToPath(new URL('../',import.meta.url)),output=process.env.WINTER_QA_OUT??path.join(root,'captures');fs.mkdirSync(output,{recursive:true});
const browser=await chromium.launch({headless:true,...(process.env.WINTER_BROWSER?{executablePath:process.env.WINTER_BROWSER}:{}),args:['--autoplay-policy=user-gesture-required',...(process.env.WINTER_SWIFTSHADER?['--use-angle=swiftshader','--enable-unsafe-swiftshader']:[])]});
const creator=pathToFileURL(path.join(root,'offline','A_Winter_Wish_Letter_Song_Lite.html')).href;const errors=[],requests=[];
const hook=page=>{page.on('pageerror',e=>errors.push(String(e)));page.on('console',log=>{if(log.type()==='error')errors.push(log.text())});page.on('request',req=>{if(/^https?:/.test(req.url()))requests.push(req.url())});};
function observeAudio(){
 window.testAudioContexts=0;
 window.playedTracks=[];
 window.clicksOutsideEnvelope=0;
 window.addEventListener('click',event=>{
  if(event.isTrusted&&!event.composedPath().some(node=>node.id==='open-envelope'))window.clicksOutsideEnvelope++;
 },true);
 const NativeContext=window.AudioContext;
 window.AudioContext=class extends NativeContext{
  constructor(...args){super(...args);window.testAudioContexts++;}
 };
 const start=AudioBufferSourceNode.prototype.start;
 AudioBufferSourceNode.prototype.start=function(...args){
  const result=start.apply(this,args);
  if(this.buffer)window.playedTracks.push(this.buffer.duration);
  return result;
 };
}
const assertSilent=async page=>{
 const audio=await page.evaluate(()=>({contexts:window.testAudioContexts,tracks:window.playedTracks}));
 assert.deepEqual(audio,{contexts:0,tracks:[]},'opening the page alone never initializes audio');
};
const waitForScore=page=>page.waitForFunction(()=>window.winterQA.audio.isRunning()&&window.playedTracks.some(seconds=>seconds>40&&seconds<43));
async function openEnvelope(page,{touch=false,beforeOpen}={}){
 const welcome=page.locator('#welcome');
 const button=welcome.getByRole('button',{name:'拆信 · 开启音乐',exact:true});
 await button.waitFor();
 assert.equal((await button.innerText()).trim(),'','the envelope has no visible labels');
 await beforeOpen?.();
 if(touch)await button.tap();
 else await button.click();
 await welcome.waitFor({state:'hidden'});
}
async function go(page,url,query,options){
 await page.goto(url+query);
 await openEnvelope(page,options);
 await page.locator('#scene[data-ready=true]').waitFor({timeout:20000});
 assert(await page.evaluate(()=>!!window.winterQA?.renderer?.getContext()));
}
const readHudOpacity=page=>page.evaluate(()=>['#mast','#controls'].map(selector=>Number(getComputedStyle(document.querySelector(selector)).opacity)));
function waitForHud(page,opacity){
 return page.waitForFunction(expected=>['#mast','#controls'].every(selector=>{
  const node=document.querySelector(selector);
  return Math.abs(Number(getComputedStyle(node).opacity)-expected)<.01;
 }),opacity);
}
const treeYaw=page=>page.evaluate(()=>window.winterQA.scene.getObjectByName('Stationary tree assembly').rotation.y);
function waitForTreeTurn(page,yaw,amount){
 return page.waitForFunction(({yaw,amount})=>window.winterQA.scene.getObjectByName('Stationary tree assembly').rotation.y-yaw>amount,{yaw,amount},{timeout:20000});
}
async function dragTreeOnTouch(page,steps=[148,168,188,208]){
 const session=await page.context().newCDPSession(page);
 const send=(type,touchPoints)=>session.send('Input.dispatchTouchEvent',{type,touchPoints});
 const point=x=>({x,y:365,id:0});
 try{
  await send('touchStart',[point(128)]);
  for(const x of steps)await send('touchMove',[point(x)]);
  await send('touchEnd',[]);
 }finally{await session.detach();}
}
async function observeMountedPhotoSwing(page){
 await page.waitForFunction(()=>{
  let photo;
  window.winterQA.scene.traverse(node=>{if(node.isMesh&&node.userData.photo===0)photo=node;});
  return !!photo;
 });
 await page.evaluate(()=>{
  const {scene,photos}=window.winterQA,update=photos.update;
  let face;
  scene.traverse(node=>{if(node.isMesh&&node.userData.photo===0)face=node;});
  const resting=face.parent.quaternion.clone(),swing={peak:0,angle:0};
  window.testMobileSwing=swing;
  photos.update=(...args)=>{
   const result=update(...args);
   swing.angle=resting.angleTo(face.parent.quaternion);
   swing.peak=Math.max(swing.peak,swing.angle);
   return result;
  };
 });
}
async function verifyTouchFlight(page){
 const timing=await page.evaluate(()=>{
  const {s,seq}=window.winterQA;
  return {state:s.flightSeconds,scene:seq.flightTiming().secondsPerProgress};
 });
 assert(timing.state>=5.8&&timing.state<=6.2,'the sleigh uses the unhurried phone timing');
 assert.equal(timing.scene,timing.state,'the camera and snow sequence share the same flight timing');
 await page.locator('#flight-direct').tap();
 await page.waitForFunction(()=>{
  const {s,seq}=window.winterQA;
  return s.phase==='flight'&&s.t>3.2&&seq.rig.visible;
 },null,{timeout:25000});
}
async function verifyTouchShowcase(page){
 await page.evaluate(()=>{
  const {photos,act,s}=window.winterQA,update=photos.update;
  const sample={min:Infinity,max:0,origin:null,originDrift:0,featured:false};
  window.testTouchOrbit=sample;
  photos.update=(time,open,formation,options)=>{
   const featured=update(time,open,formation,options);
   sample.featured=featured;
   if(s.target>.5&&open>.93&&Number.isFinite(options.orbitTurn)){
    const speed=act.yawSpeed();
    sample.min=Math.min(sample.min,speed);sample.max=Math.max(sample.max,speed);
    const origin=options.orbitPhase-2*Math.PI*(options.orbitCycle+options.orbitTurn);
    sample.origin??=origin;
    sample.originDrift=Math.max(sample.originDrift,Math.abs(origin-sample.origin));
   }
   return featured;
  };
 });
 await page.getByRole('button',{name:'散开回忆'}).tap();
 await page.waitForFunction(()=>{
  const sample=window.testTouchOrbit;
  if(!sample.featured||sample.max-sample.min<.14)return false;
  window.winterQA.s.lock=true;
  return true;
 },null,{timeout:25000});
 try{
  const {min,max,originDrift}=await page.evaluate(()=>window.testTouchOrbit);
  assert(min>.48&&max<.96,'the reduced-motion orbit eases at a gentler phone pace');
  assert(originDrift<.03,'the featured photo shares the continuous orbit phase');
  await page.screenshot({path:path.join(output,'10b-mobile-showcase.png')});
 }finally{
  await page.evaluate(()=>{window.winterQA.s.lock=false;});
 }
}
try{
 const c=await browser.newContext({offline:true,viewport:{width:1024,height:700},acceptDownloads:true});
 await c.addInitScript(observeAudio);
 const p=await c.newPage();hook(p);
 await go(p,creator,'?qa=1&phase=tree',{beforeOpen:async()=>{
  await assertSilent(p);
  await p.screenshot({path:path.join(output,'00-envelope.png')});
  await p.mouse.click(5,5);
  assert.equal(await p.evaluate(()=>window.clicksOutsideEnvelope),1,'a real click lands outside the envelope button');
  assert(await p.locator('#welcome').isVisible(),'clicking outside leaves the envelope sealed');
  await assertSilent(p);
 }});
 assert.deepEqual(await readHudOpacity(p),[0,0],'opening the envelope at the center leaves both desktop rails hidden');
 await waitForScore(p);
 const openStudio=async()=>{
  await p.mouse.move(12,12);
  await p.locator('#wish-open').click();
 };
 await openStudio();const demo=JSON.parse(fs.readFileSync(path.join(root,'offline','demo-data-flurry.json'),'utf8')).photos.slice(0,3);
 await p.locator('#wish-studio').getByText(/最多\s*24\s*张照片/).waitFor();
 await p.locator('#wish-studio input[type=file]').first().setInputFiles(demo.map((it,i)=>({name:'offline-'+i+'.jpg',mimeType:'image/jpeg',buffer:Buffer.from(it.src.split(',')[1],'base64')})));
 await p.getByText('3 / 24 张',{exact:false}).waitFor();await p.locator('#wish-title').fill('离线验证');await p.locator('#wish-recipient').fill('亲爱的朋友：');const body='温暖的冬夜。</script> & $&';
 const frameWish='愿照片里的笑声，在每个冬天都响起。';
 await p.getByRole('textbox',{name:'相框文字：offline-0'}).fill(frameWish);
 await p.locator('#wish-body').fill(body);await p.locator('#wish-signature').fill('');
 await p.getByText('已保存到此浏览器',{exact:false}).waitFor();
 await go(p,creator,'?qa=1&phase=tree');await openStudio();
 await p.getByText('3 / 24 张',{exact:false}).waitFor();
 assert.equal(await p.getByRole('textbox',{name:'相框文字：offline-0'}).inputValue(),frameWish,'photo wording survives local draft reload');
 assert.equal(await p.locator('#wish-body').inputValue(),body,'draft restores text offline after refresh');
 assert.equal(await p.locator('#wish-signature').inputValue(),'','draft keeps intended empty fields');
 const save=p.waitForEvent('download');await p.getByRole('button',{name:'导出分享 HTML'}).click();const download=await save,exported=path.join(output,'test-export.html');await download.saveAs(exported);await c.close();
 const r=await browser.newContext({offline:true,viewport:{width:1024,height:700}});
 await r.addInitScript(observeAudio);
 const recipient=await r.newPage();hook(recipient);const share=pathToFileURL(exported).href;
 await go(recipient,share,'?qa=1&phase=tree',{beforeOpen:()=>assertSilent(recipient)});
 await waitForScore(recipient);
 await recipient.waitForFunction(()=>window.winterQA.photos.items.length===3);
 assert.equal(await recipient.evaluate(()=>window.winterQA.photos.items[0].caption),frameWish,'the frame wording is in the standalone share');
 await recipient.waitForFunction(()=>{
  const strip=window.winterQA.scene.getObjectByName('Photo blessing strip');
  return strip?.parent?.userData.photo===0&&strip.material.map.image.width>=600;
 });
 assert.equal(await recipient.locator('#wish-open').count(),0);
 const firstYaw=await recipient.evaluate(()=>{const q=window.winterQA;q.play();return q.scene.getObjectByName('Stationary tree assembly').rotation.y;});
 await recipient.waitForFunction(yaw=>window.winterQA.scene.getObjectByName('Stationary tree assembly').rotation.y>yaw+.0001,firstYaw);
 assert.deepEqual(await readHudOpacity(recipient),[0,0],'the turning tree does not reveal either rail');
 const {width,height}=recipient.viewportSize();
 await recipient.mouse.move(width/2,10);
 await waitForHud(recipient,1);
 await recipient.mouse.move(width/2,height/2);
 await waitForHud(recipient,0);
 await recipient.mouse.move(width/2,height-10);
 await waitForHud(recipient,1);
 await recipient.getByRole('button',{name:'散开回忆',exact:true}).click();
 await recipient.waitForFunction(()=>window.winterQA.s.target>.5);
 assert.deepEqual(await readHudOpacity(recipient),[1,1],'clicking to scatter photos leaves both rails visible');
 await recipient.mouse.move(width/2,height/2);
 await waitForHud(recipient,0);
 await recipient.mouse.move(width/2,height-10);
 await waitForHud(recipient,1);
 await recipient.getByRole('button',{name:'收拢照片',exact:true}).click();
 await recipient.waitForFunction(()=>window.winterQA.s.target===0);
 assert.deepEqual(await readHudOpacity(recipient),[1,1],'clicking to gather photos leaves both rails visible');
 assert.equal(await recipient.locator('#letter-body').textContent(),body);
 await recipient.mouse.move(12,12);await recipient.locator('#time-control summary').click();const dial=recipient.locator('#daylight');assert.equal(await dial.inputValue(),'100');
 for(const [value,label] of [['0','白天'],['50','黄昏'],['100','夜晚']]){
  await dial.fill(value);assert.equal(await dial.getAttribute('aria-valuetext'),label);
 }
 await recipient.locator('#time-control summary').click();
 const quiet=()=>recipient.evaluate(()=>{let n=window.winterQA.seq.rig;while(n){if(!n.visible)return true;n=n.parent}return false});
 assert(await quiet());await recipient.evaluate(()=>window.winterQA.seek('intro',.88));await recipient.waitForTimeout(250);assert(await quiet());
 const shots=[['01-initial','intro',.17],['02-forming','intro',.77],['03-tree','tree',0],['04-orbit','orbit',0],['04b-bell','bell',36],['04c-bell-closed','bell-closed',36],['05-distant-santa','flight',.31],['06-drift','flight',.68],['07-covered','snow',0],['08-partial-letter','snow',.44],['09-letter','letter',1]];
 for(const [name,phase,v] of shots){await recipient.evaluate(([a,b])=>window.winterQA.seek(a,b),[phase,v]);await recipient.waitForTimeout(280);await recipient.screenshot({path:path.join(output,name+'.png')})}
 await recipient.mouse.move(width/2,height-10);await waitForHud(recipient,1);
 await recipient.locator('#read').click();assert.equal(await recipient.locator('#letter-body').textContent(),body);
 await recipient.locator('#close-letter').click();
 await recipient.setViewportSize({width:390,height:844});await recipient.evaluate(()=>window.winterQA.seek('tree'));await recipient.waitForTimeout(400);await recipient.screenshot({path:path.join(output,'10-mobile.png')});
 await r.close();
 const phone=await browser.newContext({offline:true,viewport:{width:390,height:844},isMobile:true,hasTouch:true,reducedMotion:'reduce'});
 await phone.addInitScript(observeAudio);
 const mobile=await phone.newPage();hook(mobile);
 await go(mobile,share,'?qa=1&phase=tree',{touch:true,beforeOpen:()=>assertSilent(mobile)});
 await waitForScore(mobile);
 assert(await mobile.evaluate(()=>window.winterQA.s.reduced),'system reduced motion stays in effect on touch');
 await mobile.evaluate(()=>window.winterQA.play());
 const mobileIdleYaw=await treeYaw(mobile);
 const idleLights=await mobile.evaluate(()=>{
  const {scene}=window.winterQA,flow=scene.getObjectByName('Gold flows around stationary tree');
  const bulbs=scene.getObjectByName('Selective bulb halos').geometry.getAttribute('aData');
  return {time:flow.material.uniforms.time.value,pulses:Array.from({length:8},(_,i)=>bulbs.getY(i))};
 });
 await mobile.waitForTimeout(3400);
 await waitForTreeTurn(mobile,mobileIdleYaw,.06);
 await mobile.waitForFunction(({time,pulses})=>{
  const {scene}=window.winterQA,flow=scene.getObjectByName('Gold flows around stationary tree');
  const bulbs=scene.getObjectByName('Selective bulb halos').geometry.getAttribute('aData');
  return flow.visible&&flow.material.uniforms.time.value>time+.05&&
   pulses.some((alpha,i)=>Math.abs(bulbs.getY(i)-alpha)>.005);
 },idleLights,{timeout:20000});
 await observeMountedPhotoSwing(mobile);
 const mobileDragYaw=await treeYaw(mobile);
 await dragTreeOnTouch(mobile,[160,220,282]);
 await waitForTreeTurn(mobile,mobileDragYaw,.5);
 await mobile.waitForFunction(()=>window.testMobileSwing.peak>.35,{},{timeout:10000});
 await mobile.waitForFunction(()=>window.testMobileSwing.angle<.12,{},{timeout:12000});
 assert.deepEqual(await readHudOpacity(mobile),[1,1],'touch-only HUD stays available without hovering');
 await verifyTouchShowcase(mobile);
 await mobile.getByRole('button',{name:'随机抓一张'}).tap();
 const blessings=mobile.locator('#photo-blessing');
 await blessings.waitFor();
 const firstBlessing=await blessings.innerText();
 assert(firstBlessing.length>=12,'each photo carries a distinct wish');
 await mobile.getByRole('button',{name:'下一张'}).tap();
 assert.notEqual(await blessings.innerText(),firstBlessing);
 await mobile.getByRole('button',{name:'关闭相册'}).tap();
 await mobile.getByRole('button',{name:'收拢照片'}).tap();
 assert.equal(await mobile.evaluate(()=>window.winterQA.s.target),0);
 await verifyTouchFlight(mobile);
 await mobile.evaluate(()=>window.winterQA.seek('snow'));await mobile.getByRole('button',{name:'直接读信'}).tap();
 assert.equal(await mobile.locator('#accessible-letter #letter-body').innerText(),body);
 await mobile.getByRole('button',{name:'关闭来信'}).tap();await mobile.screenshot({path:path.join(output,'11-mobile-snow.png')});
 await mobile.evaluate(()=>window.winterQA.seek('letter'));await mobile.screenshot({path:path.join(output,'12-mobile-letter.png')});
 await mobile.getByRole('button',{name:'返回圣诞树'}).tap();
 assert.equal(await mobile.evaluate(()=>window.winterQA.s.phase),'tree');
 await phone.close();
 const regularPhone=await browser.newContext({offline:true,viewport:{width:390,height:844},isMobile:true,hasTouch:true,reducedMotion:'no-preference'});
 const regularMobile=await regularPhone.newPage();hook(regularMobile);
 await go(regularMobile,share,'?qa=1',{touch:true});
 const intro=await regularMobile.evaluate(()=>({phase:window.winterQA.s.phase,time:window.winterQA.s.t}));
 assert(intro.phase==='intro'&&intro.time<5,'the normal phone experience begins with the intro');
 const introYaw=await treeYaw(regularMobile);
 await dragTreeOnTouch(regularMobile);
 assert.equal(await regularMobile.evaluate(()=>window.winterQA.s.phase),'tree','a horizontal touch drag makes the scene interactive during the intro');
 await waitForTreeTurn(regularMobile,introYaw,.5);
 await verifyTouchFlight(regularMobile);
 await regularPhone.close();
 const fallback=await browser.newContext({offline:true,viewport:{width:390,height:844}});
 const reader=await fallback.newPage();
 await reader.addInitScript(()=>{
  const getContext=HTMLCanvasElement.prototype.getContext;
  HTMLCanvasElement.prototype.getContext=function(type,...args){return /webgl/.test(type)?null:getContext.call(this,type,...args);};
 });
 reader.on('pageerror',e=>errors.push(String(e)));
 await reader.goto(share);await openEnvelope(reader);await reader.locator('#failure').waitFor();
 assert.equal(await reader.locator('#fallback-letter #letter-body').innerText(),body);
 assert(await reader.locator('#fallback-letter #letter-signature').isHidden());
 await reader.getByRole('button',{name:'查看随信照片'}).click();
 assert.equal(await reader.locator('#index').innerText(),'1 / 3');
 assert.equal(await reader.locator('#photo-blessing').innerText(),frameWish,'the text remains available in the fallback gallery');
 await reader.waitForFunction(()=>document.querySelector('#print').naturalWidth>0);
 await fallback.close();
 assert.deepEqual(requests,[],'network requests');assert.deepEqual(errors,[],'renderer/console/errors');
 console.log('PASS real offline file:// envelope, explicitly started original score, creator, export, fresh recipient, synchronized desktop HUD, phone lights and orbit showcase, touch drag and sleigh timing, fallback, screenshots, and no external requests. Visual reference comparison remains manual.');
}finally{await browser.close()}
