import assert from 'node:assert/strict';import * as T from '../dist/three.module.js';
import {makeState} from '../dist/state.js';import {makeWorldBuild} from '../dist/world-build.js';
const s=makeState();const wait=t=>{for(let i=0;i<Math.round(t*50);i++)s.tick(.02)};
assert.equal(s.phase,'intro');wait(4);assert(s.formation>.02&&s.formation<.2);wait(3.5);assert.equal(s.phase,'tree');s.toggle();wait(.2);assert(s.open>.4&&s.open<.95);
s.toggle();wait(2);assert.equal(s.open,0);s.toggle();wait(2);assert.equal(s.open,1);
s.flight();wait(6);assert.equal(s.phase,'snow');wait(30);assert.equal(s.phase,'snow','never auto-wipe');s.expose(.3);s.expose(.1);assert.equal(s.coverage,.3);s.expose(.65);assert.equal(s.phase,'letter');wait(2);assert.equal(s.reveal,1);s.replay();wait(7.4);assert.equal(s.phase,'tree');assert.equal(s.open,0);
const short=makeState(true);assert.equal(short.phase,'tree');assert.equal(short.flightSeconds,2.4);short.flight(1.5);short.tick(2.9);assert.equal(short.phase,'flight');assert(short.sleigh>1);short.tick(1.2);assert.equal(short.phase,'snow');assert.equal(short.sleigh,1.5);
assert.equal(makeState().flightSeconds,4.8);
for(const reduced of [false,true]){
 const mobile=makeState(reduced,{touchScene:true});
 assert.equal(mobile.flightSeconds,6);
 mobile.ready();
 mobile.flight(1.25);
 mobile.tick(6);
 assert.equal(mobile.phase,'flight');
 assert.equal(mobile.sleigh,.83);
 mobile.tick(2.51);
 assert.equal(mobile.phase,'flight','hold the sleigh until the snow sequence finishes');
 mobile.tick(.01);
 assert.equal(mobile.phase,'snow');
 assert.equal(mobile.sleigh,1.25);
}
const scene=new T.Scene(),ground=new T.Mesh(new T.PlaneGeometry(20,12).rotateX(-Math.PI*.5),new T.MeshStandardMaterial());ground.position.y=-.12;scene.add(ground);
const w=makeWorldBuild(T,scene,[{mesh:ground,phase:'ground'}],{density:.1});w.update(2,0);assert(!ground.visible&&!w.active[0].point.visible);w.update(2,.3);assert(w.active[0].point.visible);w.update(4,1);assert(ground.visible&&!w.active[0].point.visible);assert.equal(w.active[0].point.geometry.attributes.position.count,510);
assert(w.active[0].point.geometry.attributes.position.array.every((n,i)=>i%3!==1||Math.abs(n+.12)<.001));
console.log('Intro cadence → settled scene → reversible tree → flight → explicit snow wipe → full letter → replay; surface targets in source mesh.');
