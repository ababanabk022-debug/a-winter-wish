import assert from 'node:assert/strict';import {makeBellAct,BELL_WAIT,BELL_PULL,ORBIT_SPEED,BELL_LAND,orbitRhythm,mobileOrbitRhythm} from '../dist/bell.js';
const act=makeBellAct();assert(act.orbitalScale()>1.05);assert.equal(act.beginPull(),false);act.observe(100);
const speed=act.yawSpeed();assert.equal(speed,ORBIT_SPEED);act.observe(100+(BELL_WAIT-.05)*1000);assert(act.showTime<0);assert.equal(act.orbitalTime,0);
act.observe(100+(BELL_WAIT+BELL_LAND-.01)*1000);assert(!act.ready());
act.observe(100+(BELL_WAIT+BELL_LAND+.01)*1000);assert(act.ready());assert.equal(act.pulled,-1,'clock cannot call flight itself');assert.equal(act.orbitalTime,0);
assert(act.start());assert(!act.start());
for(let cycle=0;cycle<4;cycle++){
 for(const t of [1,3,5]){
  const f=orbitRhythm(cycle*6+t);assert.equal(f.speed,ORBIT_SPEED);assert.equal(f.scale,1.20);
  assert.equal(f.cycle,cycle);assert.equal(f.spotlight,t===5?.5:null);
 }
 const a=orbitRhythm(cycle*6),b=orbitRhythm(cycle*6+6);
 assert(Math.abs(b.angle-a.angle-2*Math.PI)<1e-10);assert.equal(b.speed,orbitRhythm(cycle*6+5.999999).speed);
 act.tick(.1,6);
}
assert(act.beginPull());assert(!act.beginPull());assert(!act.tick(BELL_PULL-.25,8));assert.equal(act.orbitalScale(),1);assert(act.tick(.26));
act.reset(true);assert(act.ready());assert.equal(act.orbitalTime,0);act.reset();act.observe(60000);assert.equal(act.time,0);assert.equal(act.orbitalTime,0);assert.equal(act.pulled,-1);assert(act.beginPull(true));assert(!act.physicalPull);
for(const seconds of [7.4,8.8]){
 const orbit=t=>mobileOrbitRhythm(t,seconds);
 const cold=orbit(0),fast=orbit(seconds/2),full=orbit(seconds);
 assert(fast.speed>cold.speed&&cold.speed>0);
 assert(Math.abs(full.angle-cold.angle-2*Math.PI)<1e-10);
 assert(Math.abs(full.speed-cold.speed)<1e-10);
 for(const time of [.2,seconds*.38,seconds*.78,seconds+.2]){
  const at=orbit(time);
  assert(Math.abs(at.angle-(at.cycle+at.turn)*2*Math.PI)<1e-10);
  const actualRate=(orbit(time+.0001).angle-orbit(time-.0001).angle)/.0002;
  assert(Math.abs(actualRate-at.speed)<1e-6,'the carousel speed and shot progress share the same clock');
 }
 const mobile=makeBellAct(orbit);mobile.start();mobile.tick(.1,seconds/2);
 assert.equal(mobile.yawSpeed(),fast.speed);
 assert(mobile.beginPull(true));
 assert.equal(mobile.yawSpeed(),fast.speed);
 mobile.tick(.45);
 assert(mobile.yawSpeed()>0&&mobile.yawSpeed()<fast.speed);
}
console.log('PASS visit clock, desktop orbit, eased mobile orbit and smooth handoff from carousel to sleigh.');
