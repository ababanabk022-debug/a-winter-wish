import * as T from '../dist/three.module.js';import {makeEnvironment} from '../dist/environment.js';import assert from 'node:assert/strict';
const scene=new T.Scene(),e=makeEnvironment(T,scene),sky=scene.children.find(m=>m.material?.uniforms?.skyVeil);
assert(scene.children.filter(m=>m!==sky&&m.isMesh&&!m.material.transparent).every(m=>sky.renderOrder>m.renderOrder));
assert(sky.material.depthTest&&!sky.material.depthWrite&&!sky.material.transparent,'sky uses opaque depth to reject hidden pixels');
assert.equal(sky.material.uniforms.daylightAmount.value,0);const L=c=>.2126*c.r+.7152*c.g+.0722*c.b;
const tones=[];
for(const v of [0,.25,.5,.75,1]){
 e.setDaylight(v);const fog=scene.fog.color,veil=sky.material.uniforms.skyVeil.value;
 assert(fog.equals(veil));tones.push(L(fog));assert.equal(sky.material.uniforms.daylightAmount.value,v*v*(3-2*v));
 for(const {mesh,phase} of e.buildLayers)if(phase==='mountain'){
  const {position:p,color:c}=mesh.geometry.attributes;let delta=0,n=0;
  for(let j=0;j<p.count;j++)if(p.getY(j)<1){delta+=Math.hypot(c.getX(j)-fog.r,c.getY(j)-fog.g,c.getZ(j)-fog.b);n++}
  assert(n>100&&delta/n<.035,'lower mountain must fade onto fog at all manual positions');
 }
 const prev=sky.material.uniforms.daylightAmount.value;e.update(4000+v);assert.equal(sky.material.uniforms.daylightAmount.value,prev,'dial cannot follow animation clock');
}
assert(tones.every((t,i)=>i===0||t>tones[i-1]));assert(tones[4]-tones[0]>.25);
e.setDaylight(-2);assert.equal(sky.material.uniforms.daylightAmount.value,0);e.setDaylight(2);assert.equal(sky.material.uniforms.daylightAmount.value,1);
console.log('PASS manual five-step continuum, default night, day/dusk monotonic veil, fog at mountain bases, no autoplay:',tones.map(n=>+n.toFixed(4)));
