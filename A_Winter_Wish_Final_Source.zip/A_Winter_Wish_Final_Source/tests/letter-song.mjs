import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {makeWishAudio} from '../dist/audio.js';
import {wishAudioMedia} from '../dist/audio-recordings.js';
class Param {
 value=0;
 setTargetAtTime(value){this.value=value}
 setValueAtTime(value){this.value=value}
}
class Context {
 state='suspended';currentTime=0;destination={};gains=[];sources=[];permitted=false;blocked=[];
 createGain(){const g={gain:new Param,connect(){},disconnect(){}};this.gains.push(g);return g}
 decodeAudioData(buf,done){const b={size:buf.byteLength};done(b);return Promise.resolve(b)}
 resume(){if(!this.permitted)return new Promise(r=>this.blocked.push(r));this.state='running';for(const r of this.blocked.splice(0))r();return Promise.resolve()}
 suspend(){this.state='suspended';return Promise.resolve()}
 close(){this.state='closed';return Promise.resolve()}
 createBufferSource(){const o={connect(){},disconnect(){},start(t,offset){this.from=offset;this.when=t},stop(t){this.stopped=t}};this.sources.push(o);return o}
}
const build=()=>{const ctx=new Context(),audio=makeWishAudio({ctxFactory:()=>ctx});return {ctx,audio}};
const bytes=Buffer.from(wishAudioMedia.letterMusic,'base64').length;
const score=Buffer.from(wishAudioMedia.music,'base64').length;
async function check(permitted){
 const {ctx,audio}=build();ctx.permitted=permitted;
 const attempted=audio.unlock(); // page load, not a gesture
 await new Promise(r=>setImmediate(r));
 if(!permitted){assert.equal(audio.isRunning(),false);assert.equal(ctx.sources.length,0);ctx.permitted=true;assert(await audio.unlock());}
 assert(await attempted);assert.equal(audio.isRunning(),true);assert.equal(ctx.sources.length,1);assert.equal(ctx.sources[0].buffer.size,score);
 const cutSongs=()=>ctx.sources.filter(s=>s.buffer.size===bytes);
 const frame=(phase,flightProgress=0)=>audio.update({phase,flightProgress,depth:10,pan:0});
 frame('letter');assert.equal(cutSongs().length,0,'a standalone letter is not a drift');
 for(const delay of [8,53,210]){
  ctx.currentTime+=delay;
  frame('tree');frame('flight',-.17);
  const n=cutSongs().length;
  frame('flight',.46);
  const before=ctx.gains[1].gain.value;
  frame('flight',.64);
  assert(ctx.gains[1].gain.value<before,'gradual music fade at actual tail yaw');
  frame('flight',.85);
  assert(ctx.gains[1].gain.value<.03);
  assert.equal(cutSongs().length,n);
  frame('flight',.856);
  const song=cutSongs().at(-1);assert.equal(cutSongs().length,n+1);assert.equal(song.from,0);
  assert.equal(song.loop,false);assert(Math.abs(song.when-ctx.currentTime)<.020);
  assert.equal(ctx.gains[1].gain.value,0);
  frame('flight',1);frame('snow');frame('letter');frame('letter');
  assert.equal(cutSongs().length,n+1);
  audio.setMuted(true);frame('letter');audio.setMuted(false);
  assert.equal(ctx.gains[1].gain.value,0,'unmute does not layer carols');assert.equal(cutSongs().length,n+1);
  frame('tree');assert.equal(song.stopped,undefined,'return to tree does not interrupt the second song');
  assert.equal(ctx.gains[1].gain.value,0);
  song.onended();
  ctx.currentTime+=.71;frame('tree');assert.equal(ctx.sources.at(-1),song,'pause after the second song');
  ctx.currentTime+=.02;frame('tree');assert.equal(ctx.sources.at(-1).buffer.size,score);assert.equal(ctx.sources.at(-1).from,0);
 }
 // A second drift before the track ends still restarts it without layering.
 frame('flight',.2);frame('flight',.856);frame('snow');frame('tree');
 const previous=cutSongs().at(-1);
 ctx.currentTime+=.6;frame('flight',.2);frame('flight',.64);assert(ctx.gains.at(-1).gain.value<.52);
 frame('flight',.856);
 const restarted=cutSongs().at(-1);
 assert.notEqual(previous,restarted);assert.equal(restarted.from,0);assert.equal(restarted.when,previous.stopped);
 audio.dispose();
}
await check(true);await check(false);
const tag=(html,id)=>html.match(new RegExp('<script[^>]*id="'+id+'"[^>]*>([\\s\\S]*?)</script>'))?.[1];
const blocks=r=>r.split(/^const \$m\d+=\(\(\)=>\{/m);
for(const ext of ['','_Demo']){
 const read=name=>fs.readFileSync(new URL('../offline/A_Winter_Wish_'+name+ext+'.html',import.meta.url),'utf8');
 const release=read('Letter_Song_Lite');
 const code=tag(release,'wish-runtime');
 assert.equal(blocks(code).length,13);
 new vm.Script(code);
 const nodes={'wish-shell':{textContent:tag(release,'wish-shell')},'wish-runtime':{outerHTML:'<script id="wish-runtime">'+code+'</script>'}};
 const win={};vm.runInNewContext(code.slice(0,code.indexOf('const $m0=')),{window:win,document:{getElementById:n=>nodes[n]}});
 const gift=win.buildWinterHTML(JSON.stringify({mode:'share',photos:[],letter:{body:'给你'}}));
 assert.equal(tag(gift,'wish-runtime'),code);
 assert.equal(JSON.parse(tag(gift,'wish-data')).letter.body,'给你');
}
console.log('PASS load audio allowed/blocked, gradual turn fade, repeatable offset 0, no overlap, hold through tree return, pause then cycle, mute, offline Gift.');
