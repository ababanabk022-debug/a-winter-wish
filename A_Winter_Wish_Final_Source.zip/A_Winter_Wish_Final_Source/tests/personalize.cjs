/* Unit integration without a browser socket; actual canvas codec with simulated UI file inputs. */
'use strict';
const assert=require('node:assert/strict'), {createCanvas,loadImage}=require('@napi-rs/canvas');
class El{
 constructor(tag){this.tag=tag;this.children=[];this.listeners={};this.attrs={};this.classList={add(){},remove(){}}}
 append(...c){c.forEach(x=>{this.children.push(x);x.parent=this})}remove(){this.parent?.children.splice(this.parent.children.indexOf(this),1)}
 replaceChildren(){this.children=[]}setAttribute(k,v){this.attrs[k]=v}addEventListener(k,fn){this.listeners[k]=fn}
 click(){if(!this.disabled)return this.onclick?.()}showModal(){this.open=true}close(){this.open=false}
 walk(test){if(test(this))return this;for(const c of this.children){const r=c.walk(test);if(r)return r}}
}
const doc=global.document={head:new El('head'),body:new El('body'),createElement(t){return t==='canvas'?createCanvas(1,1):t==='a'?Object.assign(new El(t),{onclick(){downloadName=this.download;}}):new El(t)},getElementById(id){return this.body.walk(x=>x.id===id)}};
global.createImageBitmap=async f=>loadImage(Buffer.from(await f.arrayBuffer()));require('../dist/personalize.js');
let photos,letter,html,blob,downloadName;const W=WinterPersonalize, buildHTML=json=>'<!doctype html><script id="wish-data" type="application/json">'+json+'</script>';
const find=fn=>doc.body.walk(fn),cl=c=>find(n=>n.className===c),ar=s=>find(n=>n.attrs['aria-label']===s);
function file(name,w,h,type='image/png'){let c=createCanvas(w,h);return new File([c.toBuffer(type)],name,{type})}
(async()=>{
 const open=W.init({onPhotos:p=>photos=p,onLetter:l=>letter=l,buildHTML});open.open();assert.equal(doc.getElementById('wish-studio').open,true);
 const upload=find(n=>n.type==='file'&&n.multiple);upload.files=[file('first.png',2032,508),file('second.webp',7,16,'image/webp')];await upload.onchange();assert.deepEqual(photos.map(p=>[p.w,p.h]),[[1440,360],[7,16]]);
 ar('上移：second').click();assert.equal(photos[0].name,'second');
 ar('替换：second').click();const replacement=find(n=>n.type==='file'&&!n.multiple);replacement.files=[file('新雪.jpg',150,260,'image/jpeg')];await replacement.onchange();assert.equal(photos.length,2);assert.equal(photos[0].name,'新雪');
 let field=doc.getElementById('wish-body');field.value='雪</script><script>alert(1)</script> & $& \u2028\n';field.listeners.input();assert.equal(letter.body,field.value);
 const timers=global.setTimeout;global.setTimeout=()=>{};URL.createObjectURL=b=>{blob=b;return 'blob:download'};await cl('save').click();global.setTimeout=timers;assert.equal(downloadName,'A_Winter_Wish_Gift.html');
 html=await blob.text();assert.equal(html.split('</script>').length,2);let j=html.slice(html.indexOf('>','<!doctype html>'.length)+1,html.lastIndexOf('</script>'));let d=JSON.parse(j);assert.equal(d.mode,'share');assert.equal(d.letter.body,field.value);
 open.dispose();const count=doc.body.children.length;const share=W.init({data:d,onPhotos:p=>photos=p,onLetter:l=>letter=l});assert.equal(doc.body.children.length,count);assert.equal(photos.length,2);assert.deepEqual([photos[0].name,photos[0].w,photos[0].h],['新雪',150,260]);const im=await loadImage(photos[0].src);assert.equal(im.height,260);
 assert.ok(!share.open);assert.equal(W.normalize({photos:[{src:'blob:foo'}]}).photos.length,0);
 let w=W.init({data:{photos:d.photos},onPhotos:p=>photos=p});ar('删除：新雪').click();ar('删除：first').click();assert.equal(photos.length,0);w.dispose();
 console.log('PASS: local PNG/WebP/JPEG encode & aspect cap, batch/order/replace/delete, safe JSON with script terminators and Chinese, distinct gift download name, actual Blob HTML and embedded JPEG decode, no share controls.');
})().catch(e=>{console.error(e);process.exitCode=1});
