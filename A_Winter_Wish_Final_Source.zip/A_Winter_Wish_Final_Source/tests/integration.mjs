// Deterministic renderer-boundary test. No pretend screenshot: GPU drawing is not asserted.
import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {pathToFileURL,fileURLToPath} from 'node:url';import {createRequire} from 'node:module';
const D=fileURLToPath(new URL('../dist/',import.meta.url));const temp=fs.mkdtempSync(path.join(os.tmpdir(),'snow-three-test-'));const req=createRequire(import.meta.url);const nc=req('@napi-rs/canvas');
const {createCanvas,Path2D}=nc;globalThis.Path2D=Path2D;globalThis.innerWidth=1280;globalThis.innerHeight=720;globalThis.location={search:'?qa=1'};globalThis.document={};const urls=new Map;const elements=new Map;function elem(id){if(elements.has(id))return elements.get(id);const l=new Map,css=new Set;const o={children:[],append(...nodes){this.children.push(...nodes)},tagName:'DIV',clientWidth:1280,clientHeight:720,classList:{toggle(k,v){v?css.add(k):css.delete(k)},add(k){css.add(k)}},dataset:{},style:{setProperty(k,v){this[k]=v}},hidden:false,open:false,value:'',attrs:{},setAttribute(k,v){this.attrs[k]=v},removeAttribute(k){delete this.attrs[k]},remove(){elements.delete(id)},contains(t){return t===this},innerHTML:'',textContent:'',focus(){globalThis.focused=o},setPointerCapture(){},onclick:null,addEventListener(k,f){(l.get(k)||l.set(k,[]).get(k)).push(f)},fire(k,e={}){e.target??=o;e.preventDefault??=()=>{};e.button??=0;e.pointerId??=1;(l.get(k)||[]).forEach(f=>f(e));o['on'+k]?.(e)},close(){o.open=false;o.fire('close')},showModal(){o.open=true},getBoundingClientRect(){return {left:0,top:0,width:1280,height:720}}};elements.set(id,o);return o;}
globalThis.window=elem('window');globalThis.document=Object.assign(elem('document'),{documentElement:elem('html'),querySelector:elem,createElement:kind=>kind==='canvas'?createCanvas(1,1):elem('created-'+kind+Math.random()),hidden:false});globalThis.devicePixelRatio=1.5;globalThis.gpuCalls=[];
const fullscreenButton=elem('#fullscreen-toggle'),root=document.documentElement;
if(!process.argv.includes('--touch')){
 document.fullscreenEnabled=true;
 root.requestFullscreen=()=>{document.fullscreenElement=root;document.fire('fullscreenchange');return Promise.resolve();};
 document.exitFullscreen=()=>{document.fullscreenElement=null;document.fire('fullscreenchange');return Promise.resolve();};
}
const reduceMotion=process.argv.includes('--reduced'),touchScene=process.argv.includes('--touch');
globalThis.matchMedia=query=>({matches:query==='(pointer: coarse)'?touchScene:query==='(prefers-reduced-motion: reduce)'&&reduceMotion});
let cb,curr=1000;globalThis.requestAnimationFrame=f=>(cb=f,1);
const taskTimers=new Map();let taskId=0;
globalThis.setTimeout=(f,ms=0)=>{const id=++taskId;taskTimers.set(id,{f,deadline:curr+ms});return id;};
globalThis.clearTimeout=id=>taskTimers.delete(id);
function pump(){for(const [id,v] of taskTimers)if(v.deadline<=curr){taskTimers.delete(id);v.f()}}
const actual=pathToFileURL(path.join(D,'three.module.js')).href;
fs.writeFileSync(path.join(temp,'shim.mjs'),`export * from '${actual}';export class WebGLRenderer{constructor(){this.shadowMap={};this.info={render:{calls:0,triangles:0}}}getContext(){return {VERSION:1,getParameter(){return 'mock'}}}setDrawingBufferSize(w,h,dpr){globalThis.gpuCalls.push(['resize',w,h,dpr]);}render(scene,camera){globalThis.gpuCalls.push(['draw']);scene.updateMatrixWorld();globalThis.scene=scene;globalThis.camera=camera}};export class PMREMGenerator{fromEquirectangular(tex){return {texture:tex}}dispose(){}}`);
let src=fs.readFileSync(path.join(D,'app.js'),'utf8').replace("'./three.module.js'",JSON.stringify(pathToFileURL(path.join(temp,'shim.mjs')).href)).replace(/from '(\.\/[^']+)'/g,(m,f)=>'from '+JSON.stringify(pathToFileURL(path.join(D,f)).href));fs.writeFileSync(path.join(temp,'entry.mjs'),src);
elem('#daylight').value='100';await import(pathToFileURL(path.join(temp,'entry.mjs')));
function advance(seconds){for(let n=0;n<Math.ceil(seconds*20);n++){curr+=50;cb(curr);pump()}}

assert(elem('#welcome').open&&!window.winterQA,'the envelope opens before scene initialization');
advance(.05);
const cv=elem('#scene'),q=window.winterQA, dial=elem('#daylight'), visible=o=>{while(o){if(!o.visible)return false;o=o.parent}return true};
assert(q?.seq?.reindeer);
assert(elem('#welcome').open);
advance(.2);
assert.equal(q.s.t,0,'the snow scene waits for the envelope');
assert.equal(q.act.startedAt,null);
assert(!document.fullscreenElement,'loading does not request fullscreen');
elem('#open-envelope').fire('click');
advance(1);
assert(!elem('#welcome').open);
if(touchScene){
 assert(!document.fullscreenElement,'an unsupported browser still opens the letter normally');
 assert.equal(fullscreenButton.attrs['aria-label'],'全屏帮助');
 assert.match(elem('#fullscreen-status').textContent,/直接打开 HTML/);
}
else{
 assert.equal(document.fullscreenElement,root,'opening the envelope requests fullscreen');
 assert.equal(fullscreenButton.attrs['aria-label'],'退出全屏');
 fullscreenButton.fire('click');
 assert.equal(document.fullscreenElement,null);
 assert.equal(fullscreenButton.attrs['aria-label'],'进入全屏');
 fullscreenButton.fire('click');
 assert.equal(document.fullscreenElement,root);
 document.exitFullscreen();
 assert.equal(fullscreenButton.attrs['aria-label'],'进入全屏','a browser exit updates the control');
}
if(process.argv.includes('--slow-desktop')){
 q.s.ready();
 cv.clientWidth=2048;cv.clientHeight=1152;window.fire('resize');gpuCalls.length=0;
 const slowFrame=()=>{curr+=180;cb(curr);pump();};
 slowFrame();
 const initial=gpuCalls.find(([kind])=>kind==='resize');
 assert(initial[1]*initial[2]*initial[3]**2<=2_600_000+.01,'the desktop buffer has a total pixel budget');
 for(let i=0;i<18;i++)slowFrame();
 const latest=gpuCalls.filter(([kind])=>kind==='resize').at(-1);
 assert(latest[3]<initial[3]&&latest[3]>=.75,'sustained frames over 100ms lower the desktop buffer');
 assert(gpuCalls.every(([kind],index)=>kind!=='resize'||gpuCalls[index+1]?.[0]==='draw'));
 fs.rmSync(temp,{recursive:true});console.log('PASS desktop pixel budget and resolution adaptation below ten FPS');process.exit(0);
}
if(!reduceMotion)q.reset();
const sourceButton=elem('#audio-info'),sourceDialog=elem('#audio-credits');
assert(!sourceButton.hidden);sourceButton.fire('click');assert(sourceDialog.open);
const authors=elem('#audio-credit-list').children.map(item=>item.children[0].textContent);
assert(authors.some(t=>t.includes('Percy Duke')));
elem('#close-audio-credits').fire('click');assert(!sourceDialog.open);
if(reduceMotion){
 assert.equal(q.s.phase,'tree');assert.equal(q.s.formation,1);
 assert(!elem('#flight-direct').hidden&&!elem('#flight-direct').disabled);
 const tree=q.scene.getObjectByName('Stationary tree assembly'),initialYaw=tree.rotation.y;
 advance(2);
 if(touchScene){assert(tree.rotation.y-initialYaw>.1);}
 else assert.equal(tree.rotation.y,0);
 let reducedSpin;const normalPhoto=q.photos.update;q.photos.update=(...args)=>{reducedSpin=args[3];return normalPhoto(...args)};
 const pointerType=touchScene?'touch':'mouse';
 cv.fire('pointerdown',{clientX:450,clientY:340,timeStamp:100,pointerType});
 cv.fire('pointermove',{clientX:750,clientY:340,timeStamp:118,pointerType});
 advance(.05);assert(tree.rotation.y>0);
 assert.equal(reducedSpin.interactiveSpin,touchScene);
 if(touchScene){assert(reducedSpin.spinVelocity>1);assert(reducedSpin.spinAcceleration>0);}
 else{assert.equal(reducedSpin.spinVelocity,0);assert.equal(reducedSpin.spinAcceleration,0);}
 cv.fire('pointerup',{clientX:750,clientY:340,timeStamp:120,pointerType});
 if(touchScene){
  advance(.15);assert(reducedSpin.spinVelocity>1,'the photos keep swinging after the touch is released');
  advance(2.4);assert.equal(reducedSpin.spinVelocity,0);
 }
 q.photos.update=normalPhoto;

 elem('#flight-direct').fire('click');assert.equal(q.act.pulled,0);
 advance(2.2);assert.equal(q.s.phase,'flight');
 fs.rmSync(temp,{recursive:true});console.log('PASS reduced-motion immediate formed state and direct sleigh action');process.exit(0);
}
assert(/id="flight-direct"[^>]* hidden disabled/.test(fs.readFileSync(path.join(D,'index.html'),'utf8')),'HTML hides direct flight before JS init');
const flightDirect=elem('#flight-direct');
assert(flightDirect.hidden&&flightDirect.disabled&&!elem('#mode').hidden);
flightDirect.fire('click');document.fire('keydown',{target:cv,key:'Enter'});
assert.equal(q.s.phase,'intro');assert.equal(q.act.pulled,-1);
q.act.time=37;q.act.showTime=2;elem('#bell-pull').fire('click');assert.equal(q.s.phase,'intro');assert.equal(q.act.pulled,-1);q.act.time=0;q.act.showTime=-1;
advance(.1);assert.equal(cv.dataset.phase,'intro');assert(!visible(q.seq.rig));assert(!visible(q.seq.reindeer));
advance(5.9);assert.equal(cv.dataset.phase,'intro');assert(!visible(q.seq.rig));advance(1.7);assert.equal(cv.dataset.phase,'tree');assert(!flightDirect.hidden&&!flightDirect.disabled);assert(!visible(q.seq.rig));
assert(gpuCalls.filter(([k])=>k==='resize').length>=2,'intro crosses adaptive DPR threshold');
assert(gpuCalls.every(([k],i)=>k!=='resize'||gpuCalls[i+1]?.[0]==='draw'),'every allocation immediately followed by a draw');
gpuCalls.length=0;cv.clientWidth=1200;window.fire('resize');assert.deepEqual(gpuCalls,[]);
advance(.05);assert.equal(gpuCalls[0][0],'resize');assert.equal(gpuCalls[1][0],'draw');
cv.clientWidth=1280;window.fire('resize');advance(.05);
const pivot=q.scene.getObjectByName('Stationary tree assembly'), input=(name,x,y=340)=>cv.fire(name,{clientX:x,clientY:y});
const drag=(a,b)=>{input('pointerdown',a);input('pointermove',b);input('pointerup',b);advance(.11);};
advance(.6);assert(pivot.rotation.y>0&&pivot.rotation.y<.041);drag(620,745);assert(pivot.rotation.y>.4);assert.equal(q.s.target,0);
input('pointerdown',620);input('pointermove',675);input('pointerleave',675);input('pointerup',675);assert.equal(q.s.target,0);
let spinFrame;const beforeSpinUpdate=q.photos.update;const treeRings=[];q.audio.jingleTree=hit=>treeRings.push(hit);
q.photos.update=(...inputs)=>{spinFrame=inputs[3];return beforeSpinUpdate(...inputs)};
const dragFrame=(kind,x,ts)=>cv.fire(kind,{clientX:x,clientY:340,timeStamp:ts});
const dragOrigin=pivot.rotation.y;
dragFrame('pointerdown',610,1000);dragFrame('pointermove',770,1030);advance(.05);
assert(pivot.rotation.y>dragOrigin+.60&&spinFrame.spinVelocity>5&&spinFrame.spinAcceleration>0);assert.equal(treeRings.length,0);
dragFrame('pointermove',490,1060);advance(.1);
assert(spinFrame.spinVelocity< -3&&spinFrame.spinAcceleration<0);
dragFrame('pointerup',490,1070);
advance(.15);assert(Math.abs(spinFrame.spinVelocity)>1);
advance(1.9);assert.equal(spinFrame.spinVelocity,0);assert.equal(spinFrame.spinAcceleration,0);
assert.equal(treeRings.length,0,'quick spin is silent; wooden sign remains independent');delete q.audio.jingleTree;
q.photos.update=beforeSpinUpdate;

cv.fire('wheel',{deltaY:180,deltaMode:0});advance(.11);assert.equal(q.camera.zoom,1);
for(let i=0;i<8;i++)cv.fire('wheel',{deltaY:-160,deltaMode:0});advance(.11);assert.equal(q.camera.zoom,1.75);
for(let i=0;i<10;i++)cv.fire('wheel',{deltaY:150,deltaMode:0});advance(.11);assert.equal(q.camera.zoom,1);
cv.fire('wheel',{deltaY:-87,deltaMode:0});advance(.11);assert(q.camera.zoom>1);const before=pivot.rotation.y;
const framedZoom=q.camera.zoom,startOrbit=q.orbitPhase;elem('#mode').fire('click');advance(.05);assert(Math.abs(q.orbitPhase-startOrbit-Math.PI/3*.05)<1e-7);assert(Math.abs(pivot.rotation.y-before)<.0025);advance(1.35);assert.equal(q.camera.zoom,framedZoom);assert(+cv.dataset.open>.99);
pivot.traverse(obj=>{if(obj.isLine)assert(!visible(obj),'no visible trails while dispersed');});assert(!elem('#mode').hidden&&!elem('#flight-direct').hidden);assert(!visible(q.seq.rig));assert(!visible(q.seq.reindeer));
const openYaw=pivot.rotation.y;drag(720,570);assert(pivot.rotation.y<openYaw-.45);assert.equal(q.s.target,1);
for(let i=0;i<10;i++)cv.fire('wheel',{deltaY:150,deltaMode:0});advance(.11);assert(q.camera.zoom>=1&&q.camera.zoom<1.15);
const hud=elem('#world');
assert.equal(hud.dataset.hud,'off','rotating photos do not reveal the rails');
assert(!elem('#mast').inert&&!elem('#controls').inert);
assert(!elem('#orbit-actions').hidden&&elem('#mode').textContent==='收拢照片');
window.fire('pointermove',{clientX:1269,clientY:44});assert.equal(hud.dataset.hud,'on','top edge works while orbiting');
elem('document').fire('keydown',{key:'Escape'});assert.equal(q.s.target,0);advance(1.1);
assert.equal(hud.dataset.hud,'on','ending orbit does not force-hide the rails');
window.fire('pointermove',{clientX:642,clientY:360});advance(1.7);assert.equal(hud.dataset.hud,'off');
cv.fire('pointerdown',{clientX:600,clientY:350});cv.fire('pointermove',{clientX:690,clientY:350});
window.fire('pointermove',{clientX:690,clientY:350});assert.equal(hud.dataset.hud,'off');
cv.fire('pointerup',{clientX:690,clientY:350});advance(.1);

advance(5);assert.equal(hud.dataset.hud,'off');
for(const target of [cv,elem('#bell-pull')]) {
 for(const event of ['pointerdown','pointerup'])window.fire(event,{target,pointerType:'mouse',clientX:1250,clientY:45});
 document.fire('focusin',{target});assert.equal(hud.dataset.hud,'off','desktop click and focus cannot wake controls');
}
document.fire('pointerleave');window.fire('blur');assert.equal(hud.dataset.hud,'off');
window.fire('pointermove',{clientX:1269,clientY:44});assert.equal(hud.dataset.hud,'on');
window.fire('pointermove',{clientX:642,clientY:360});advance(1.2);assert.equal(hud.dataset.hud,'on');advance(.5);assert.equal(hud.dataset.hud,'off');
window.fire('pointermove',{clientX:642,clientY:695});assert.equal(hud.dataset.hud,'on');
window.fire('pointermove',{clientX:642,clientY:360});advance(1.7);assert.equal(hud.dataset.hud,'off');
window.fire('pointermove',{target:cv,pointerType:'touch',clientX:600,clientY:695});assert.equal(hud.dataset.hud,'off');
elem('#mode').fire('click');advance(.9);assert.equal(q.s.target,1);assert.equal(hud.dataset.hud,'off');
for(const event of ['pointerdown','pointerup'])cv.fire(event,{pointerType:'touch',clientX:600,clientY:699});assert.equal(q.s.target,0);
advance(.85);
elem('#mode').fire('click');advance(1);assert.equal(q.s.target,1);assert.equal(hud.dataset.hud,'off');
const oldPick=q.photos.pick;q.photos.pick=()=>-1;
input('pointerdown',1275,695);input('pointerup',1275,695);
assert.equal(q.s.target,0,'empty click far outside tree reassembles');
q.photos.pick=()=>0;elem('#mode').fire('click');advance(.9);
input('pointerdown',400);input('pointerup',400);assert(elem('#book').open&&q.s.target===1,'photo wins over empty-space close');
elem('#close').fire('click');q.photos.pick=oldPick;
const catchButton=elem('#random-photo'),picked=new Set();assert(!catchButton.hidden);let firstOfNext;
for(let i=0;i<21;i++){
 catchButton.fire('click');assert(catchButton.hidden&&elem('#book').open);
 const got=elem('#print').src;if(i<20){assert(!picked.has(got));picked.add(got);}
 else firstOfNext=got;
 if(i===19)globalThis.lastPreviousPick=got;
 elem('#close').fire('click');assert(!catchButton.hidden&&q.s.target===1);
 assert.equal(globalThis.focused,catchButton);assert.equal(hud.dataset.hud,'off');
}
assert.equal(picked.size,20);assert.notEqual(firstOfNext,globalThis.lastPreviousPick);



elem('#album').fire('click');assert(elem('#book').open);assert.equal(elem('#album').attrs['aria-current'],'page');elem('#close').fire('click');assert(!elem('#book').open);
assert.equal(dial.value,'100');assert.equal(dial.attrs['aria-valuetext'],'夜晚');
for(const [x,name] of [['0','白天'],['50','黄昏'],['100','夜晚']]){dial.value=x;dial.fire('input');assert.equal(dial.attrs['aria-valuetext'],name);}
assert(q.act.running);
let liveShot;const realPhotoUpdate=q.photos.update;
q.photos.update=(...inputs)=>{liveShot=inputs[3];return realPhotoUpdate(...inputs)};
q.act.orbitalTime=3;advance(2);assert.equal(q.camera.zoom,1,'camera must stay fixed on a live orbit');
assert.equal(q.act.orbitalScale(),1.20);assert.equal(q.act.yawSpeed(),Math.PI/3,'showcase must not alter ambient orbit');
const spreadYaw=pivot.rotation.y,previousPhase=q.orbitPhase, previousShot=liveShot.orbitCycle;assert(Math.abs(liveShot.orbitTurn-5/6)<1e-9);
advance(6);assert.equal(pivot.rotation.y,spreadYaw);assert(Math.abs(q.orbitPhase-previousPhase-2*Math.PI)<1e-9);
assert.equal(liveShot.orbitCycle,previousShot+1);assert(Math.abs(liveShot.orbitTurn-5/6)<1e-9);
const galleryPhase=q.act.orbitalTime;elem('#album').fire('click');gpuCalls.length=0;advance(.65);
assert.equal(q.act.orbitalTime,galleryPhase);assert.equal(gpuCalls.length,0,'gallery pauses WebGL draws');elem('#close').fire('click');
elem('#mode').fire('click');advance(.05);assert(liveShot.orbitTurn!==undefined,'collapse blends out the same close-up');advance(7);assert.equal(liveShot.orbitTurn,undefined);q.photos.update=realPhotoUpdate;const orbitAtClose=q.act.orbitalTime;assert.equal(orbitAtClose,0,'the next fresh scatter starts at original speed');assert(catchButton.hidden);catchButton.fire('click');assert(!elem('#book').open);assert.equal(q.s.open,0);
const yaw=pivot.rotation.y;advance(3);assert(pivot.rotation.y-yaw>.112&&pivot.rotation.y-yaw<.135);assert.equal(q.camera.zoom,1);
q.act.startedAt=curr-16200;advance(.2);assert(q.act.time>=16.39&&q.act.time<16.7);assert(!q.bell.root.visible);assert(elem('#bell-pull').hidden);
document.hidden=true;curr+=2600;cb(curr);document.hidden=false;advance(.15);assert(q.act.time>=18.9,'hidden-tab elapsed counts toward the visit clock');assert(q.bell.root.visible);assert(!elem('#bell-pull').hidden);
assert.equal(q.s.open,0);assert.equal(cv.dataset.phase,'tree');assert(!visible(q.seq.rig),'a due bell does not auto-launch');
elem('#album').fire('click');advance(4);assert(q.act.time>=22.5);assert.equal(q.act.orbitalTime,orbitAtClose);elem('#close').fire('click');
advance(.1);assert(q.bell.root.visible);assert(!elem('#bell-pull').hidden);
assert(!elem('#hint').textContent.includes('拉铃'));assert(elem('#bell-pull').style.top.endsWith('%'));
const dome=q.bell.anchor??q.bell.root.children[0].children[0];const spot=dome.getWorldPosition(new (q.camera.position.constructor)()).project(q.camera);
const x=(spot.x+1)*640,y=(1-spot.y)*360;
input('pointerdown',x,y);input('pointerup',x,y);assert.equal(q.act.pulled,0,'physical bell clickable while closed');
advance(1.26);assert.equal(cv.dataset.phase,'tree');assert.equal(q.s.open,0);assert.equal(q.camera.zoom,1);assert(!visible(q.seq.rig));
advance(.35);assert.equal(cv.dataset.phase,'tree');advance(.21);assert.equal(cv.dataset.phase,'flight');assert(visible(q.seq.rig));assert(visible(q.seq.reindeer));advance(6.7);assert.equal(cv.dataset.phase,'snow');advance(2);assert.equal(cv.dataset.phase,'snow');assert(elem('#bell-pull').hidden);
q.s.expose(.95);advance(1);assert.equal(cv.dataset.phase,'letter');assert(!q.bell.root.visible);elem('#replay').fire('click');advance(4);assert.equal(cv.dataset.phase,'intro');assert(!visible(q.seq.rig));assert(!q.bell.root.visible);assert(q.act.time>27.5);assert.equal(dial.value,'100');assert(flightDirect.hidden&&flightDirect.disabled);flightDirect.fire('click');assert.equal(q.s.phase,'intro');
elem('#mode').fire('click');advance(.1);assert(!flightDirect.hidden&&!flightDirect.disabled);
advance(3.5);assert.equal(cv.dataset.phase,'tree');assert(q.bell.root.visible,'bell remains due after story replay');
elem('#mode').fire('click');advance(.7);assert(q.bell.root.visible,'opening the tree cannot hide the due bell');
assert(!elem('#flight-direct').hidden);elem('#flight-direct').fire('click');advance(1.32);assert.equal(cv.dataset.phase,'tree');assert.equal(q.s.open,0);assert.equal(q.camera.zoom,1);
advance(.5);assert.equal(cv.dataset.phase,'flight');
const rail=elem('#letter-actions'), modal=elem('#accessible-letter'), read=elem('#read');
assert(rail.hidden);
advance(6.8);assert.equal(q.s.phase,'snow');assert(!rail.hidden&&read.hidden);
elem('#skip-wipe').fire('click');assert(modal.open&&q.s.phase==='snow');
elem('#close-letter').fire('click');assert(!modal.open&&q.s.phase==='snow');
q.seq.trace(.5,.5,.2,.2,.1);assert(q.seq.sampleMask(.5,.5)>0);
let visit=q.act.startedAt;elem('#return-tree').fire('click',{pointerType:'touch'});
assertSettled();assert.equal(q.act.startedAt,visit);
openLetter();read.fire('click');assert(modal.open);
document.fire('keydown',{target:modal,key:'Escape'});assert.equal(q.s.phase,'letter'); // Browser closes modal via native cancel.
modal.close();assert(!modal.open&&rail.hidden);
read.fire('click');elem('#close-letter').fire('click');assert(!modal.open&&q.s.phase==='letter');
read.fire('click');modal.getBoundingClientRect=()=>({left:220,right:1060,top:60,bottom:660});
function tapDialog(x,y,target=modal){for(const e of ['pointerdown','pointerup'])modal.fire(e,{clientX:x,clientY:y,target});}
tapDialog(340,110,elem('#letter-copy'));assert(modal.open&&q.s.phase==='letter');
modal.fire('pointerdown',{clientX:340,clientY:110,target:elem('#letter-copy')});modal.fire('pointerup',{clientX:25,clientY:350});assert(modal.open);
modal.fire('pointerdown',{clientX:25,clientY:350});modal.fire('pointerup',{clientX:55,clientY:350});assert(modal.open);
window.getSelection=()=>({toString:()=>'文字'});tapDialog(25,350);assert(modal.open);delete window.getSelection;
tapDialog(25,350);assert(!modal.open);assertSettled();
openLetter();advance(.9);
input('pointerdown',640,360);input('pointerup',640,360);assert(q.s.phase==='letter');
cv.clientWidth=390;window.fire('resize');advance(.1);
input('pointerdown',195,360);input('pointerup',195,360);assert(q.s.phase==='letter','phone rotation must not invalidate paper hit target');
cv.clientWidth=1280;window.fire('resize');advance(.1);
input('pointerdown',28,360);input('pointerup',28,360);assertSettled();
elem('#flight-direct').fire('click');advance(9.2);assert.equal(q.s.phase,'snow');
input('pointerdown',28,360);q.s.expose(.95);advance(.9);input('pointerup',28,360);
assert.equal(q.s.phase,'letter','the last wipe pointerup must not dismiss the revealed letter');
elem('#canvas-letter-exit').fire('click');assertSettled();
openLetter();let stoppedReturn=false;document.fire('keydown',{target:cv,key:'Escape',preventDefault(){stoppedReturn=true}});assert(stoppedReturn);assertSettled();
function openLetter(){
 elem('#flight-direct').fire('click');advance(2.3);assert.equal(q.s.phase,'flight');
 advance(6.8);assert.equal(q.s.phase,'snow');q.s.expose(.95);advance(.05);
 assert.equal(q.s.phase,'letter');assert(rail.hidden&&!read.hidden&&!elem('#canvas-letter-exit').hidden);
}
function assertSettled(){
 assert.equal(q.s.phase,'tree');assert.equal(q.s.formation,1);assert.equal(q.s.open,0);assert.equal(q.s.target,0);
 assert.equal(q.s.sleigh,0);assert.equal(q.s.coverage,0);assert.equal(q.s.reveal,0);assert.equal(q.s.lock,false);
 assert.equal(q.act.pulled,-1);assert.equal(q.camera.zoom,1);assert(!q.seq.group.visible);assert(rail.hidden);
 assert.equal(q.seq.sampleMask(.5,.5),0);assert.equal(hud.dataset.hud,'off','return must not wake scene HUD');
}
console.log('PASS real entry scene graph and mocked GPU: drag/zoom, shared edge-only HUD with no click-to-hide during orbit, independent bell timing, flight and wipe flow, letter exit and mouse/touch/key return. Not a browser test.');
