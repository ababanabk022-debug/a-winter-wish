import assert from 'node:assert/strict';import * as T from '../dist/three.module.js';import {makePhotos} from '../dist/photos.js';import {createRequire} from 'node:module';
const {createCanvas,Image}=createRequire(import.meta.url)('@napi-rs/canvas');globalThis.Image=Image;
let previewEncodes=0;
globalThis.document={createElement:()=>{
 const canvas=createCanvas(1,1),encode=canvas.toDataURL.bind(canvas);
 canvas.toDataURL=(...args)=>{previewEncodes++;return encode(...args);};
 return canvas;
}};
const scene=new T.Scene(),pivot=new T.Group();scene.add(pivot);const p=makePhotos(T,pivot),root=pivot.children[0];assert.equal(p.items.length,20);
assert.equal(previewEncodes,0,'scene creation never encodes album previews');
const firstPreview=p.items[0].url;
assert.match(firstPreview,/^data:image\/jpeg;base64,/);
assert.equal(p.items[0].url,firstPreview);
assert.equal(previewEncodes,1,'the requested album image is encoded once');
assert.equal(root.children[0].children[0].material.map.image.width,960);
assert.equal(root.children[0].children[0].material.map.image.height,672);
function verifyInk(){for(const group of root.children){
 const material=group.children[0].material;
 assert(material.isMeshBasicMaterial && material.map && material.map.colorSpace===T.SRGBColorSpace);
 assert.equal(material.map.anisotropy,8);
 assert.equal(material.toneMapped,false);assert.equal(material.color.getHex(),0xe5e5e5);
 assert.equal(material.emissive,undefined);assert.equal(material.transparent,false);
 assert.equal(material.blending,T.NormalBlending);assert.equal(material.side,T.DoubleSide);
}}
verifyInk();
const photo=createCanvas(80,52),ctx=photo.getContext('2d');let event=0;let data=Array.from({length:25},(_,i)=>{ctx.fillStyle='rgb('+i*8+',140,160)';ctx.fillRect(0,0,80,52);return {src:photo.toDataURL(),name:'照片 '+(i+1),w:80,h:52}});
root.children[0].children[0].material.addEventListener('dispose',()=>event++);
assert.equal(await p.replace(data),24);assert.equal(event,1);assert.equal(p.items.length,24);verifyInk();assert.equal(new Set(p.items.map(i=>i.url)).size,24);
assert.equal(new Set(p.items.map(i=>i.caption)).size,24,'each uploaded photo receives a distinct default blessing');
for(const aspect of [.43,1.77]){
 const camera=new T.PerspectiveCamera(aspect<1?56:40,aspect,.05,380);camera.position.set(0,1.86,11.7);camera.lookAt(0,2.48,0);camera.updateMatrixWorld(true);
 const ray=new T.Raycaster();
 for(let t=0;t<25;t+=.5){assert.equal(pivot.rotation.y,0);p.update(t,1,1,{camera,portrait:aspect<1,orbitalScale:1.34});scene.updateMatrixWorld(true);
 let hits=0;for(const g of root.children){const v=g.getWorldPosition(new T.Vector3()).project(camera);assert(Math.abs(v.x)<.98&&Math.abs(v.y)<.98);ray.setFromCamera(v,camera);if(p.pick(ray)>=0)hits++}assert(hits>=17);
 }
 const hangerTop=g=>g.children[1].children[1].localToWorld(new T.Vector3(0,.064,0));
 p.update(0,0,1,{camera,reduced:true});const calm=root.children.map(g=>g.quaternion.clone()),pins=root.children.map(hangerTop);
 p.update(17,0,1,{camera,reduced:true});assert(root.children.every((g,i)=>g.quaternion.angleTo(calm[i])<1e-7),'reduced motion keeps mounted prints fixed');
 if(aspect<1){
  const flick={camera,reduced:true,interactiveSpin:true,dt:1/60};
  for(let frame=0;frame<20;frame++)p.update(0,0,1,{...flick,spinVelocity:9,spinAcceleration:25});
  const flying=root.children.map(g=>g.quaternion.clone());
  assert(flying.every((q,i)=>q.angleTo(calm[i])>.85),'a deliberate phone flick lifts every mounted print');
  root.children.forEach((g,i)=>assert(hangerTop(g).distanceTo(pins[i])<1e-8,'the cord anchor holds while lifting'));
  p.update(0,0,1,flick);
  assert(root.children.every((g,i)=>g.quaternion.angleTo(flying[i])<.10),'releasing the flick does not snap prints back');
  for(let frame=0;frame<110;frame++)p.update(0,0,1,flick);
  assert(root.children.every((g,i)=>g.quaternion.angleTo(calm[i])<1e-3),'the flick settles back to the neutral hang');
 }
 let actual=0;
 for(let t=0;t<12;t+=.2){p.update(t,0,1,{camera});root.children.forEach((g,i)=>{assert(hangerTop(g).distanceTo(pins[i])<1e-8,'cord tip stays attached');
 const angle=g.quaternion.angleTo(calm[i]);assert(angle<Math.PI*11/180,'wind sway never exceeds 11 degrees');actual=Math.max(angle,actual);});}
 assert(actual>Math.PI*5/180,'mounted motion is visibly stronger');
 p.update(5,0,1,{camera});const start=root.children.map(g=>g.position.clone());p.update(5,.7,1,{camera});p.update(5,0,1,{camera});assert(root.children.every((g,i)=>g.position.distanceTo(start[i])<1e-8));
}
const [first,second,third,fourth]=root.children.map(group=>group.children[0].material.map);
let disposed=0;fourth.addEventListener('dispose',()=>disposed++);
assert.equal(await p.replace([data[2],data[0],data[1]]),3);
assert.equal(disposed,1);
assert.deepEqual(root.children.map(group=>group.children[0].material.map),[third,first,second]);
assert.deepEqual(root.children.map(group=>group.children[0].userData.photo),[0,1,2]);
assert.deepEqual(p.items.map(item=>item.url),[data[2].src,data[0].src,data[1].src]);

const original=createCanvas(1152,720),large={src:original.toDataURL(),name:'大图'};
const superseded=p.replace([data[4]]),latest=p.replace([large,{...large,name:'同一个画面'}]);
assert.equal(await superseded,0);
assert.equal(await latest,2);
const [largeFace,duplicate]=root.children.map(group=>group.children[0]);
assert.equal(largeFace.material.map,duplicate.material.map);
assert.equal(largeFace.material.map.image.width,960);
assert.equal(largeFace.material.map.image.height,600);
assert.equal(p.items[0].url,large.src);

const shortBlessing='愿你眼里一直有光';
const longBlessing='愿星光照亮归家的路'.repeat(8).slice(0,64);
const captioned=[{...large,caption:' '+longBlessing+' '},{...large,name:'同一个画面',caption:shortBlessing}];
assert.equal(await p.replace(captioned),2);
assert.deepEqual(p.items.map(item=>item.caption),[longBlessing,shortBlessing]);
const [largeStrip,duplicateStrip]=[largeFace,duplicate].map(face=>face.getObjectByName('Photo blessing strip'));
assert(largeStrip&&duplicateStrip);
assert.equal(largeStrip.geometry,duplicateStrip.geometry,'caption strips share geometry');
assert.equal(largeStrip.material.side,T.FrontSide);
assert.equal(largeStrip.material.map.image.width,768);
assert(largeStrip.material.map.image.height>duplicateStrip.material.map.image.height,'long CJK wording wraps on the photo');
assert(largeStrip.scale.y<=.46&&largeStrip.position.y<0,'strip fits within the lower part of the face');
assert.equal(root.children[0].children[0],largeFace,'editing the blessing keeps the original photo mesh');
assert.equal(largeFace.material.map,duplicate.material.map,'captioned duplicates still share the original texture');
assert.equal(p.items[0].url,large.src);

let retiredCaptionMaps=0,retiredCaptionMaterials=0;
largeStrip.material.map.addEventListener('dispose',()=>retiredCaptionMaps++);
largeStrip.material.addEventListener('dispose',()=>retiredCaptionMaterials++);
await p.replace(captioned);
assert.equal(largeFace.getObjectByName('Photo blessing strip'),largeStrip,'unchanged captions are reused');
await p.replace([{...captioned[0],caption:'  '},captioned[1]]);
assert.equal(largeFace.getObjectByName('Photo blessing strip'),undefined);
assert.equal(duplicate.getObjectByName('Photo blessing strip'),duplicateStrip);
assert.equal(retiredCaptionMaps,1);
assert.equal(retiredCaptionMaterials,1);
assert.ok(p.items[0].caption);
assert.notEqual(p.items[0].caption,longBlessing);
duplicateStrip.material.map.addEventListener('dispose',()=>retiredCaptionMaps++);
assert.equal(await p.replace([]),20);assert.equal(root.children.length,20);
assert.equal(retiredCaptionMaps,2,'removing an image releases its caption texture');
assert(root.children.every(group=>!group.getObjectByName('Photo blessing strip')),'built-in art already has baked wording');
const withPhotos=makePhotos(T,new T.Group(),{hasInitialPhotos:true});
assert.equal(withPhotos.items.length,0);
assert.equal(await withPhotos.replace([data[0]]),1);
console.log('PASS photo framing, touch flick and fixed tethers, picking, texture reuse, bounded HD maps, optional caption strips and restoration');
