import assert from 'node:assert/strict';import * as T from '../dist/three.module.js';import {makePhotos} from '../dist/photos.js';import {createRequire} from 'node:module';
const {createCanvas,Image}=createRequire(import.meta.url)('@napi-rs/canvas');globalThis.document={createElement:()=>createCanvas(1,1)};globalThis.Image=Image;
const scene=new T.Scene(),pivot=new T.Group();scene.add(pivot);const p=makePhotos(T,pivot),root=pivot.children[0];assert.equal(p.items.length,20);
function verifyInk(){for(const group of root.children){
 const material=group.children[0].material;
 assert(material.isMeshBasicMaterial && material.map && material.map.colorSpace===T.SRGBColorSpace);
 assert.equal(material.toneMapped,false);assert.equal(material.color.getHex(),0xe5e5e5);
 assert.equal(material.emissive,undefined);assert.equal(material.transparent,false);
 assert.equal(material.blending,T.NormalBlending);assert.equal(material.side,T.DoubleSide);
}}
verifyInk();
const photo=createCanvas(80,52),ctx=photo.getContext('2d');let event=0;let data=Array.from({length:25},(_,i)=>{ctx.fillStyle='rgb('+i*8+',140,160)';ctx.fillRect(0,0,80,52);return {src:photo.toDataURL(),name:'照片 '+(i+1),w:80,h:52}});
root.children[0].children[0].material.addEventListener('dispose',()=>event++);
assert.equal(await p.replace(data),24);assert.equal(event,1);assert.equal(p.items.length,24);verifyInk();assert.equal(new Set(p.items.map(i=>i.url)).size,24);
for(const aspect of [.43,1.77]){
 const camera=new T.PerspectiveCamera(aspect<1?56:40,aspect,.05,380);camera.position.set(0,1.86,11.7);camera.lookAt(0,2.48,0);camera.updateMatrixWorld(true);
 const ray=new T.Raycaster();
 for(let t=0;t<25;t+=.5){assert.equal(pivot.rotation.y,0);p.update(t,1,1,{camera,portrait:aspect<1,orbitalScale:1.34});scene.updateMatrixWorld(true);
 let hits=0;for(const g of root.children){const v=g.getWorldPosition(new T.Vector3()).project(camera);assert(Math.abs(v.x)<.98&&Math.abs(v.y)<.98);ray.setFromCamera(v,camera);if(p.pick(ray)>=0)hits++}assert(hits>=17);
 }
 const hangerTop=g=>g.children[1].children[1].localToWorld(new T.Vector3(0,.064,0));
 p.update(0,0,1,{camera,reduced:true});const calm=root.children.map(g=>g.quaternion.clone()),pins=root.children.map(hangerTop);
 p.update(17,0,1,{camera,reduced:true});assert(root.children.every((g,i)=>g.quaternion.angleTo(calm[i])<1e-7),'reduced motion keeps mounted prints fixed');
 let actual=0;
 for(let t=0;t<12;t+=.2){p.update(t,0,1,{camera});root.children.forEach((g,i)=>{assert(hangerTop(g).distanceTo(pins[i])<1e-8,'cord tip stays attached');
 const angle=g.quaternion.angleTo(calm[i]);assert(angle<Math.PI*11/180,'wind sway never exceeds 11 degrees');actual=Math.max(angle,actual);});}
 assert(actual>Math.PI*5/180,'mounted motion is visibly stronger');
 p.update(5,0,1,{camera});const start=root.children.map(g=>g.position.clone());p.update(5,.7,1,{camera});p.update(5,0,1,{camera});assert(root.children.every((g,i)=>g.position.distanceTo(start[i])<1e-8));
}
const [first,second,third,fourth]=root.children.map(group=>group.children[0].material.map);
let disposed=0;fourth.addEventListener('dispose',()=>disposed++);
assert.equal(await p.replace([data[2],data[0],data[1]]),3);
assert.equal(disposed,1);
assert.deepEqual(root.children.map(group=>group.children[0].material.map),[third,first,second]);
assert.deepEqual(root.children.map(group=>group.children[0].userData.photo),[0,1,2]);
assert.deepEqual(p.items.map(item=>item.url),[data[2].src,data[0].src,data[1].src]);

const original=createCanvas(1152,720),large={src:original.toDataURL(),name:'大图'};
const superseded=p.replace([data[4]]),latest=p.replace([large,{...large,name:'同一个画面'}]);
assert.equal(await superseded,0);
assert.equal(await latest,2);
const [largeFace,duplicate]=root.children.map(group=>group.children[0]);
assert.equal(largeFace.material.map,duplicate.material.map);
assert.equal(largeFace.material.map.image.width,768);
assert.equal(largeFace.material.map.image.height,480);
assert.equal(p.items[0].url,large.src);

assert.equal(await p.replace([]),20);assert.equal(root.children.length,20);
const withPhotos=makePhotos(T,new T.Group(),{hasInitialPhotos:true});
assert.equal(withPhotos.items.length,0);
assert.equal(await withPhotos.replace([data[0]]),1);
console.log('PASS photo framing, picking, texture reuse, thumbnail sizing, latest update, and restoration');
