import {createRequire} from 'node:module';import fs from 'node:fs';import {execFileSync} from 'node:child_process';
import path from 'node:path';
const require=createRequire(import.meta.url),{createCanvas,GlobalFonts}=require('@napi-rs/canvas');
const chineseFonts=['Kaiti SC','KaiTi','STKaiti','Songti SC','Noto Serif CJK SC','Noto Serif SC','SimSun','PingFang SC','Microsoft YaHei','Noto Sans CJK SC','Noto Sans SC','WenQuanYi Zen Hei'];
const hasChineseFont=()=>chineseFonts.some(family=>GlobalFonts.has(family));
if(!hasChineseFont()&&process.env.WINDIR){
 const font=path.join(process.env.WINDIR,'Fonts','simkai.ttf');
 if(fs.existsSync(font))GlobalFonts.registerFromPath(font,'KaiTi');
}
if(!hasChineseFont())throw new Error('Preparing demo postcards needs an installed Chinese font such as Noto Serif CJK SC.');
globalThis.document={createElement:()=>createCanvas(1,1)};
const {getPicture,memories}=await import('../dist/photos.js');
const photos=memories.map(({title},i)=>{
 const artwork=getPicture(i);
 return {name:title,src:artwork.toDataURL('image/jpeg',.91),w:artwork.width,h:artwork.height};
});
const demo={mode:'share',photos,letter:{title:'一封寄自雪夜的信',recipient:'亲爱的朋友：',body:'窗外飘着雪，树上留着一盏灯。\n\n愿你也有一个不用赶路的冬夜，有值得珍藏的回忆，还有一个让你觉得安心的人。\n\n圣诞快乐。',signature:'写于十二月的某个晚上'}};
fs.mkdirSync('offline',{recursive:true});fs.writeFileSync('offline/demo-data-flurry.json',JSON.stringify(demo));execFileSync(process.execPath,['scripts/pack.mjs'],{stdio:'inherit'});
