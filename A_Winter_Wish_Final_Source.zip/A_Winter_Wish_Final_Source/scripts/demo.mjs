import {createRequire} from 'node:module';import fs from 'node:fs';import {execFileSync} from 'node:child_process';
const require=createRequire(import.meta.url),{createCanvas}=require('@napi-rs/canvas');
globalThis.document={createElement:()=>createCanvas(1,1)};
const {getPicture,memories}=await import('../dist/photos.js');
const photos=Array.from({length:20},(_,i)=>{const c=getPicture(i);return {name:memories[i].title,src:c.toDataURL('image/jpeg',.87),w:c.width,h:c.height}});
const demo={mode:'share',photos,letter:{title:'一封寄自雪夜的信',recipient:'亲爱的朋友：',body:'窗外飘着雪，树上留着一盏灯。\n\n愿你也有一个不用赶路的冬夜，有值得珍藏的回忆，还有一个让你觉得安心的人。\n\n圣诞快乐。',signature:'写于十二月的某个晚上'}};
fs.mkdirSync('offline',{recursive:true});fs.writeFileSync('offline/demo-data-flurry.json',JSON.stringify(demo));execFileSync(process.execPath,['scripts/pack.mjs'],{stdio:'inherit'});
