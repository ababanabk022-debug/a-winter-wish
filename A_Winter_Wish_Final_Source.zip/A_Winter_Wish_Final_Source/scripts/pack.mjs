import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';import {createRequire} from 'node:module';import {fileURLToPath} from 'node:url';
const ROOT=fileURLToPath(new URL('../',import.meta.url)),dist=file=>path.join(ROOT,'dist',file);
const args=process.argv.slice(2);
if(args.some(arg=>arg!=='--creator-only'&&arg!=='--refresh-three'))throw Error('Usage: node scripts/pack.mjs [--creator-only] [--refresh-three]');

// Keep the readable engine for module development and use its minified twin in offline HTML.
const threeSource=fs.readFileSync(dist('three.module.js'),'utf8');
const threeHash=createHash('sha256').update(threeSource).digest('hex');
const esbuildVersion='0.25.12';
const threeHeader='// Generated from three.module.js by esbuild '+esbuildVersion+'. Source SHA-256: '+threeHash+'\n';
const threeFile=dist('three.offline.js');
if(args.includes('--refresh-three')){
 const require=createRequire(import.meta.url);
 let esbuild;
 try{esbuild=require('esbuild')}catch(error){
  throw Error('Install esbuild@'+esbuildVersion+' to refresh the offline Three.js build.',{cause:error});
 }
 if(esbuild.version!==esbuildVersion)throw Error('Expected esbuild@'+esbuildVersion+' for a reproducible offline build.');
 const {code}=esbuild.transformSync(threeSource,{format:'esm',legalComments:'inline',minifyWhitespace:true,minifyIdentifiers:true,keepNames:true});
 const exports=code.match(/export\{[\w$ ,]+\};\s*$/);
 if(!exports)throw Error('Cannot identify the minified Three.js exports.');
 fs.writeFileSync(threeFile,threeHeader+code.slice(0,exports.index)+'\n'+exports[0]);
}
const threeOffline=fs.readFileSync(threeFile,'utf8');
if(!threeOffline.startsWith(threeHeader))throw Error('Offline Three.js build is out of date. Run node scripts/pack.mjs --refresh-three.');
const src=file=>file==='three.module.js'?threeOffline:fs.readFileSync(dist(file),'utf8');
const ids=['three.module.js','environment.js','fir.js','photos.js','state.js','world-build.js','reindeer.js','sleigh-sequence.js','bell.js','audio-recordings.js','audio.js','app.js'];
const objects=Object.fromEntries(ids.map((n,i)=>[n,'$m'+i]));
function compile(filename){
 const name=objects[filename],defs=[];let text=src(filename).replace(/^import\s+(.+?)\s+from\s+['"]\.\/([^'"]+)['"];?\s*$/gm,(_,names,dep)=>{
  if(!objects[dep])throw new Error('Unknown bundle import '+dep);
  return 'const '+(names.startsWith('* as ')?names.slice(5):names.replaceAll(/\bas\b/g,':'))+'='+objects[dep]+';';
 });
 text=text.replace(/^export\s+(?:(async)\s+)?(function|class|const|let|var)\s+([A-Za-z_$][\w$]*)/gm,(_,a,k,n)=>{defs.push(n);return (a?a+' ':'')+k+' '+n;});
 text=text.replace(/^export\s*\{([^}]*?)\}\s*;?/gm,(_,parts)=>{for(const p of parts.split(',')){const [a,b]=p.trim().split(/\s+as\s+/);if(a)defs.push(b?b+':'+a:a);}return ''});
 if(/^\s*(?:import|export)\s/m.test(text))throw Error('Unsupported ES module form in '+filename);
 return 'const '+name+'=(()=>{\n'+text+'\nreturn {'+defs.join(',')+'};\n})();\n';
}
const shield=s=>s.replaceAll(/<\/script/gi,'<\\/script');
const esc=x=>JSON.stringify(x).replaceAll('<','\\u003c').replaceAll('>','\\u003e').replaceAll('&','\\u0026').replaceAll('\u2028','\\u2028').replaceAll('\u2029','\\u2029');
const sorted=[],sorting=new Set(),done=new Set();
function addDependencies(filename){
 if(done.has(filename))return;
 if(sorting.has(filename))throw Error('Circular offline bundle import '+filename);
 sorting.add(filename);
 for(const [,dependency] of src(filename).matchAll(/^import\s+.+?\s+from\s+['"]\.\/([^'"]+)['"];?\s*$/gm)){
  if(!objects[dependency])throw Error('Unknown bundle import '+dependency);
  addDependencies(dependency);
 }
 sorting.delete(filename);done.add(filename);sorted.push(filename);
}
for(const id of ids)addDependencies(id);
const creator=src('personalize.js'),bundle=sorted.map(compile).join('\n');
const script=(id,content)=>'<script id="'+id+'">\n'+shield(content)+'\n</script>';
const slots={DATA:'@@WISH_DATA_08@@',RUNTIME:'@@WISH_RUNTIME_08@@',SHELL:'@@WISH_SHELL_08@@'};
let shell=src('index.html').replace('<link rel="stylesheet" href="./style.css">','<style>'+src('style.css')+'</style>')
.replace(/<script type="application\/json" id="wish-data">.*?<\/script>/s, '<script type="application/json" id="wish-data">'+slots.DATA+'</script>')
.replace('<script defer src="./personalize.js"></script><script type="module" src="./app.js"></script>', '<script id="wish-shell" type="application/json">'+slots.SHELL+'</script>'+slots.RUNTIME);
const setup=`
window.buildWinterHTML=(json)=>{
 const shellNode=document.getElementById('wish-shell');
 const shell=JSON.parse(shellNode.textContent);
 const code=document.getElementById('wish-runtime').outerHTML;
 const safe=JSON.stringify(JSON.parse(json)).replace(/[<>&\\u2028\\u2029]/g,c=>'\\\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));
 const map={${JSON.stringify(slots.DATA)}:safe,${JSON.stringify(slots.RUNTIME)}:code,${JSON.stringify(slots.SHELL)}:shellNode.textContent};
 return shell.replace(/@@WISH_(?:DATA|RUNTIME|SHELL)_08@@/g,m=>map[m]);
};
`;
const runtime=script('wish-runtime',setup+'\n'+creator+'\n'+bundle);
const build=data=>shell.replace(/@@WISH_(?:DATA|RUNTIME|SHELL)_08@@/g,m=>({[slots.DATA]:esc(data),[slots.RUNTIME]:runtime,[slots.SHELL]:esc(shell)})[m]);
const out=path.resolve(process.env.WISH_PACK_OUT||path.join(ROOT,'offline'));
const prefix='A_Winter_Wish_Letter_Song_Lite';
const releaseData=[
 ['',{mode:'creator',photos:[]}]
];
if(!args.includes('--creator-only')){
 const demo=JSON.parse(fs.readFileSync(path.join(ROOT,'offline','demo-data-flurry.json'),'utf8'));
 releaseData.push(['_Demo',{...demo,mode:'share'}]);
}
fs.mkdirSync(out,{recursive:true});
for(const [suffix,data] of releaseData){
 const name=prefix+suffix+'.html',html=build(data);
 fs.writeFileSync(path.join(out,name),html);
 console.log(name,Buffer.byteLength(html),'bytes');
}
