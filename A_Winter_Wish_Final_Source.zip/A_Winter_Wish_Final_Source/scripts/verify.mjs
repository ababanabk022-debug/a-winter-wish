import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const extended=process.argv.slice(2).includes('--with-geometry');
const root=fileURLToPath(new URL('../',import.meta.url));
const run=file=>execFileSync(process.execPath,[file],{cwd:root,stdio:'inherit'});
const suites=['state.mjs','pack.mjs','bell.mjs','audio.mjs','letter-song.mjs','accepted-parity.mjs'];
if(extended)suites.push('daylight.mjs','demo.mjs','personalize.cjs','photos.mjs','wipe.mjs','drift.mjs','snow-tail.mjs','integration.mjs');
run('scripts/pack.mjs');
for(const name of suites)run('tests/'+name);
